"""
GOOSE Configuration
"""

import os

# Load environment variables from .env file if it exists
try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass  # python-dotenv not installed, use system env vars

# Snapshot configuration
SNAPSHOT_SPACE = os.environ.get('SNAPSHOT_SPACE', "council.graphprotocol.eth")
SNAPSHOT_API_URL = os.environ.get('SNAPSHOT_API_URL', "https://hub.snapshot.org/graphql")

# Safe configuration - Multiple Safes support
SAFES = [
    {
        "address": "0x8C6de8F8D562f3382417340A6994601eE08D3809",
        "chain": "arbitrum",
        "safe_chain": "arb1",  # Safe App uses "arb1" prefix for Arbitrum One
        "api_url": "https://safe-transaction-arbitrum.safe.global/api/v1",
        "label": "Council Multisig (Arbitrum)"
    },
    {
        "address": "0x48301Fe520f72994d32eAd72E2B6A8447873CF50",
        "chain": "ethereum",
        "safe_chain": "eth",  # Safe App uses "eth" prefix for Ethereum mainnet
        "api_url": "https://safe-transaction-mainnet.safe.global/api/v1",
        "label": "Council Multisig (Ethereum)"
    }
]

# Backward compatibility - use first Safe as default
SAFE_ADDRESS = SAFES[0]["address"]
SAFE_CHAIN = SAFES[0]["chain"]
SAFE_API_URL = SAFES[0]["api_url"]

# Database - configurable via environment variable for Docker
DATA_DIR = os.environ.get('GOOSE_DATA_DIR', os.path.dirname(os.path.abspath(__file__)))
DATABASE_PATH = os.environ.get('GOOSE_DATABASE_PATH', os.path.join(DATA_DIR, 'goose.db'))

# Output directory - should be sibling to data directory
# If DATABASE_PATH is /app/data/goose.db, output is /app/output
DATA_PARENT = os.path.dirname(DATABASE_PATH)
OUTPUT_DIR = os.environ.get('GOOSE_OUTPUT_DIR', os.path.join(DATA_PARENT, 'output'))

# Quorum threshold
QUORUM_THRESHOLD = int(os.environ.get('QUORUM_THRESHOLD', 6))
TOTAL_MEMBERS = int(os.environ.get('TOTAL_MEMBERS', 10))

# Notion configuration
NOTION_CONFIG = {
    "api_token": os.environ.get('NOTION_API_TOKEN'),
    "database_id": os.environ.get('NOTION_DATABASE_ID'),
    "voters_database_id": os.environ.get('NOTION_VOTERS_DATABASE_ID'),
    "active_statuses": os.environ.get('NOTION_ACTIVE_STATUSES', 'In Progress,Not Started').split(','),
    "label": "Notion Governance"
}

# Alert configuration
SLACK_MENTION_USERS = os.environ.get('SLACK_MENTION_USERS', '')

# Environment-aware Slack webhook configuration
# Uses ENVIRONMENT variable to decide which webhook to use
ENVIRONMENT = os.environ.get('ENVIRONMENT', 'staging').lower()

SLACK_WEBHOOK_URL_STAGING = os.environ.get('SLACK_WEBHOOK_URL_STAGING', '')
SLACK_WEBHOOK_URL_PROD = os.environ.get('SLACK_WEBHOOK_URL_PROD', '')

# Select webhook based on environment
if ENVIRONMENT == 'production':
    SLACK_WEBHOOK_URL = SLACK_WEBHOOK_URL_PROD
else:
    SLACK_WEBHOOK_URL = SLACK_WEBHOOK_URL_STAGING
