"""
Fuzzy Name Matching for Notion to Council Member Addresses
Handles matching Notion names to council member CSV addresses using fuzzy matching
"""

from rapidfuzz import fuzz, process
from typing import Optional, Dict, List
import council_lookup


# Cache for council members
_council_members_cache = None


def _load_council_members() -> Dict[str, str]:
    """Load council members from CSV and build name->address mapping"""
    global _council_members_cache

    if _council_members_cache is not None:
        return _council_members_cache

    members = council_lookup.load_council_members()

    # Build reverse mapping: name variations -> address
    name_to_address = {}

    for address, info in members.items():
        # Add full name (lowercase for case-insensitive matching)
        name = info.get('name', '').strip().lower()
        if name:
            name_to_address[name] = address

        # Add ENS if available (lowercase)
        ens = info.get('ens', '').strip().lower()
        if ens:
            name_to_address[ens] = address

        # Add first name only (common in Notion - people often use first names)
        if name:
            first_name = name.split()[0] if ' ' in name else name
            if first_name:
                name_to_address[first_name] = address

    _council_members_cache = name_to_address
    return name_to_address


def match_notion_name_to_address(notion_name: str, min_score: int = 70) -> Optional[str]:
    """
    Match Notion name to council member address using fuzzy matching

    Args:
        notion_name: Name from Notion voter
        min_score: Minimum fuzzy match score (0-100), default 70

    Returns:
        Matched address (lowercase) or None if no match found
    """
    if not notion_name:
        return None

    name_to_address = _load_council_members()

    # Strip whitespace
    notion_name_clean = notion_name.strip()

    if not notion_name_clean:
        return None

    # Convert to lowercase for matching
    notion_name_lower = notion_name_clean.lower()

    # Try exact match first (case-insensitive)
    if notion_name_lower in name_to_address:
        return name_to_address[notion_name_lower]

    # Try fuzzy matching
    # Get list of candidate names
    candidate_names = list(name_to_address.keys())

    # Use rapidfuzz to find best match
    result = process.extractOne(
        notion_name_lower,
        candidate_names,
        scorer=fuzz.WRatio
    )

    if result and result[1] >= min_score:
        matched_name = result[0]
        return name_to_address[matched_name]

    return None


def batch_match_names(notion_names: List[str]) -> Dict[str, Optional[str]]:
    """
    Batch match multiple Notion names to addresses

    Args:
        notion_names: List of names from Notion

    Returns:
        Dict mapping notion_name -> address (or None)
    """
    results = {}
    for name in notion_names:
        results[name] = match_notion_name_to_address(name)
    return results


def get_match_statistics(notion_names: List[str]) -> Dict:
    """
    Get statistics about name matching

    Args:
        notion_names: List of names from Notion

    Returns:
        Dict with match_rate, unmatched_names, etc.
    """
    if not notion_names:
        return {
            'total': 0,
            'matched': 0,
            'unmatched': 0,
            'match_rate': 0.0,
            'unmatched_names': []
        }

    matches = batch_match_names(notion_names)
    matched_count = sum(1 for addr in matches.values() if addr is not None)

    return {
        'total': len(notion_names),
        'matched': matched_count,
        'unmatched': len(notion_names) - matched_count,
        'match_rate': matched_count / len(notion_names) if notion_names else 0,
        'unmatched_names': [name for name, addr in matches.items() if addr is None]
    }


if __name__ == "__main__":
    # Test fuzzy matching
    print("Testing fuzzy name matching...")

    # Test with known names from CSV
    test_names = ["Julien", "Santi", "Chris", "Nonexistent"]

    for name in test_names:
        address = match_notion_name_to_address(name)
        if address:
            print(f"✓ '{name}' -> {address}")
        else:
            print(f"✗ '{name}' -> No match")

    # Test batch matching
    print("\nBatch matching:")
    results = batch_match_names(["Julien", "Santiago", "FakePerson"])
    for name, addr in results.items():
        print(f"  {name}: {addr}")

    # Test statistics
    print("\nStatistics:")
    stats = get_match_statistics(["Julien", "Santiago", "FakePerson"])
    print(f"  Total: {stats['total']}")
    print(f"  Matched: {stats['matched']}")
    print(f"  Unmatched: {stats['unmatched']}")
    print(f"  Match rate: {stats['match_rate']:.1%}")
