"""
Notion API Client with Rate Limiting
Handles Notion API interactions with built-in rate limit awareness
"""

import requests
import time
from typing import List, Dict, Optional


class NotionClient:
    """Notion API client with rate limiting"""

    BASE_URL = "https://api.notion.com/v1"

    def __init__(self, token: str, database_id: str):
        self.token = token
        self.database_id = database_id
        self.headers = {
            "Authorization": f"Bearer {token}",
            "Notion-Version": "2022-06-28",
            "Content-Type": "application/json"
        }

    def query_database(self) -> List[Dict]:
        """
        Query all pages from the database
        Handles pagination automatically

        Returns:
            List of all pages in the database
        """
        url = f"{self.BASE_URL}/databases/{self.database_id}/query"

        all_pages = []
        has_more = True
        next_cursor = None

        while has_more:
            payload = {}
            if next_cursor:
                payload["start_cursor"] = next_cursor

            response = requests.post(url, json=payload, headers=self.headers)
            response.raise_for_status()
            data = response.json()

            all_pages.extend(data.get("results", []))
            has_more = data.get("has_more", False)
            next_cursor = data.get("next_cursor")

            # Rate limiting: small delay between pagination requests
            # Notion free tier has a rate limit of 3 requests/second
            if has_more:
                time.sleep(0.3)

        return all_pages

    def fetch_related_pages(self, page_id: str, relation_property: str) -> List[Dict]:
        """
        Fetch pages related through a relation property

        Args:
            page_id: The ID of the page containing the relation
            relation_property: The name of the relation property

        Returns:
            List of related pages
        """
        # First, get the page to retrieve relation IDs
        url = f"{self.BASE_URL}/pages/{page_id}"
        response = requests.get(url, headers=self.headers)
        response.raise_for_status()
        page_data = response.json()

        # Extract relation IDs
        relations = page_data.get("properties", {}).get(relation_property, {}).get("relation", [])
        related_ids = [r["id"] for r in relations]

        # Fetch each related page
        related_pages = []
        for related_id in related_ids:
            url = f"{self.BASE_URL}/pages/{related_id}"
            response = requests.get(url, headers=self.headers)
            response.raise_for_status()
            related_pages.append(response.json())

            # Rate limiting: delay between requests
            time.sleep(0.3)

        return related_pages

    def get_page(self, page_id: str) -> Dict:
        """
        Get a single page by ID

        Args:
            page_id: The ID of the page to fetch

        Returns:
            Page data as dictionary
        """
        url = f"{self.BASE_URL}/pages/{page_id}"
        response = requests.get(url, headers=self.headers)
        response.raise_for_status()
        return response.json()


if __name__ == "__main__":
    # Test the client (requires valid credentials)
    import os

    token = os.environ.get("NOTION_API_TOKEN")
    database_id = os.environ.get("NOTION_DATABASE_ID")

    if token and database_id:
        print(f"Testing Notion client with database: {database_id}")
        client = NotionClient(token, database_id)

        try:
            pages = client.query_database()
            print(f"✓ Found {len(pages)} pages")

            # Show first page structure
            if pages:
                print(f"\nFirst page ID: {pages[0]['id']}")
                print(f"Properties: {list(pages[0].get('properties', {}).keys())}")

        except Exception as e:
            print(f"✗ Error: {e}")
    else:
        print("Set NOTION_API_TOKEN and NOTION_DATABASE_ID to test")
