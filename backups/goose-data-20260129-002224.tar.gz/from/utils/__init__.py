"""
Utility modules for grumpygoose
"""
