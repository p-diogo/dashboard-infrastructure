"""
Retry utility with exponential backoff for API requests
"""

import time
import random
import requests
from functools import wraps


def with_retry(
    max_retries: int = 5,
    initial_delay: float = 1.0,
    max_delay: float = 60.0,
    jitter: bool = True,
    timeout: int = 30
):
    """
    Decorator for retrying functions with exponential backoff

    Args:
        max_retries: Maximum number of retry attempts
        initial_delay: Initial delay in seconds before first retry
        max_delay: Maximum delay between retries
        jitter: Add random jitter to prevent thundering herd
        timeout: Request timeout in seconds
    """
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            last_error = None

            for attempt in range(max_retries):
                try:
                    # Add timeout to kwargs if not present
                    if 'timeout' not in kwargs and 'requests' in str(func.__module__):
                        kwargs['timeout'] = timeout

                    return func(*args, **kwargs)

                except requests.exceptions.Timeout as e:
                    last_error = e
                    if attempt < max_retries - 1:
                        delay = _calculate_delay(attempt, initial_delay, max_delay, jitter)
                        print(f"  ⏱️ Timeout on attempt {attempt + 1}, retrying in {delay:.2f}s...")
                        time.sleep(delay)
                    continue

                except requests.exceptions.HTTPError as e:
                    status_code = e.response.status_code if hasattr(e, 'response') else None

                    # Don't retry client errors (4xx) except 429
                    if status_code and 400 <= status_code < 500 and status_code != 429:
                        raise

                    last_error = e
                    if attempt < max_retries - 1:
                        delay = _calculate_delay(attempt, initial_delay, max_delay, jitter)

                        if status_code == 429:
                            print(f"  🚦 Rate limited (429), retrying in {delay:.2f}s...")
                        else:
                            print(f"  ⚠️ HTTP error {status_code}, retrying in {delay:.2f}s...")

                        time.sleep(delay)
                    continue

                except (requests.exceptions.ConnectionError,
                        requests.exceptions.RequestException) as e:
                    last_error = e
                    if attempt < max_retries - 1:
                        delay = _calculate_delay(attempt, initial_delay, max_delay, jitter)
                        print(f"  🔌 Connection error, retrying in {delay:.2f}s...")
                        time.sleep(delay)
                    continue

            # All retries exhausted
            raise Exception(f"Max retries ({max_retries}) exceeded. Last error: {last_error}")

        return wrapper
    return decorator


def _calculate_delay(attempt: int, initial_delay: float, max_delay: float, jitter: bool) -> float:
    """Calculate exponential backoff delay with optional jitter"""
    delay = min(initial_delay * (2 ** attempt), max_delay)
    if jitter:
        delay += random.uniform(0, 1)
    return delay


# Circuit breaker for repeated failures
class CircuitBreaker:
    """Circuit breaker pattern to prevent cascading failures"""

    def __init__(self, failure_threshold: int = 5, timeout: int = 60):
        self.failure_threshold = failure_threshold
        self.timeout = timeout
        self.failures = 0
        self.last_failure_time = None
        self.state = 'closed'  # closed, open, half-open

    def call(self, func, *args, **kwargs):
        """Execute function with circuit breaker protection"""
        if self.state == 'open':
            if time.time() - self.last_failure_time > self.timeout:
                self.state = 'half-open'
                print("  🔓 Circuit breaker entering half-open state")
            else:
                raise Exception("Circuit breaker is OPEN - blocking request")

        try:
            result = func(*args, **kwargs)
            if self.state == 'half-open':
                self.state = 'closed'
                self.failures = 0
                print("  ✅ Circuit breaker closed")
            return result
        except Exception as e:
            self.failures += 1
            self.last_failure_time = time.time()

            if self.failures >= self.failure_threshold:
                self.state = 'open'
                print(f"  🚨 Circuit breaker OPEN after {self.failures} failures")
            raise
