# Cron Setup for Automatic Data Updates

This directory contains scripts and instructions for setting up automatic data updates.

## Quick Setup

### 1. Copy the update script to VPS

```bash
scp deployments/update-data.sh root@your-vps:/usr/local/bin/grumpygoose-update.sh
ssh root@your-vps "chmod +x /usr/local/bin/grumpygoose-update.sh"
```

### 2. Set up Cron on VPS

```bash
# SSH into VPS
ssh root@your-vps

# Edit crontab
crontab -e

# Add these lines:
# Update staging every 2 hours
0 */2 * * * /usr/local/bin/grumpygoose-update.sh grumpygoose-staging >> /var/log/grumpygoose-staging.log 2>&1

# Update production every 6 hours
0 */6 * * * /usr/local/bin/grumpygoose-update.sh grumpygoose-prod >> /var/log/grumpygoose-prod.log 2>&1
```

### 3. Verify Cron is Working

```bash
# Check cron logs
tail -f /var/log/grumpygoose-staging.log

# Or trigger manually
/usr/local/bin/grumpygoose-update.sh grumpygoose-staging
```

## What This Does

The cron job will:
1. Run `python setup.py` inside the running container
2. This fetches new data from APIs
3. Updates the database in the persistent volume
4. The dashboard automatically shows the new data on next page refresh

## No Container Restart Needed

The container keeps running and serving files. When cron updates the data:
- Database is updated in the shared volume
- Dashboard shows new data on page refresh
- No downtime, no restart

## Alternative: Docker-Based Cron

If you prefer not to use host cron, you can enable the built-in cron container:

```bash
# Start with cron profile
docker-compose -f docker-compose.yml -f docker-compose.staging.yml --profile cron-staging up -d
```

This runs a separate container that updates data on a schedule.

## Comparison

| Approach | Pros | Cons |
|----------|------|------|
| Host cron (recommended) | Simple, easy to debug, lighter | Requires access to VPS |
| Docker cron container | Self-contained, portable | More complex, heavier |
| Manual updates | Full control | Must remember to run |
