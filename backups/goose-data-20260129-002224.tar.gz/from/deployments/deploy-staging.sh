#!/bin/bash
# Deploy grumpygoose to staging environment

set -e  # Exit on error

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Configuration
VPS_HOST="${VPS_HOST:-}"
VPS_USER="${VPS_USER:-root}"
DEPLOY_PATH="/opt/grumpygoose-staging"
DOCKER_IMAGE="grumpygoose:staging"

echo -e "${GREEN}==================================================${NC}"
echo -e "${GREEN}🪿 GRUMPY GOOSE - Staging Deployment${NC}"
echo -e "${GREEN}==================================================${NC}"
echo ""

# Check if VPS_HOST is set
if [ -z "$VPS_HOST" ]; then
    echo -e "${RED}Error: VPS_HOST environment variable not set${NC}"
    echo "Usage: VPS_HOST=your-vps.com ./deploy-staging.sh"
    exit 1
fi

# Step 1: Build Docker image locally
echo -e "${YELLOW}[1/6] Building Docker image locally...${NC}"
docker build -t "$DOCKER_IMAGE" .

# Step 2: Save image to tarball
echo -e "${YELLOW}[2/6] Exporting Docker image...${NC}"
docker save "$DOCKER_IMAGE" | gzip > grumpygoose-staging.tar.gz

# Step 3: Copy files to VPS
echo -e "${YELLOW}[3/6] Copying files to VPS...${NC}"
ssh "$VPS_USER@$VPS_HOST" "mkdir -p $DEPLOY_PATH"
scp grumpygoose-staging.tar.gz "$VPS_USER@$VPS_HOST:$DEPLOY_PATH/"
scp docker-compose.yml "$VPS_USER@$VPS_HOST:$DEPLOY_PATH/"
scp docker-compose.staging.yml "$VPS_USER@$VPS_HOST:$DEPLOY_PATH/"
scp .env.staging "$VPS_USER@$VPS_HOST:$DEPLOY_PATH/.env" 2>/dev/null || echo "# No .env.staging file, skipping"

# Step 4: Load image on VPS
echo -e "${YELLOW}[4/6] Loading Docker image on VPS...${NC}"
ssh "$VPS_USER@$VPS_HOST" "cd $DEPLOY_PATH && docker load < grumpygoose-staging.tar.gz"

# Step 5: Create Docker network if it doesn't exist
echo -e "${YELLOW}[5/6] Setting up Docker network...${NC}"
ssh "$VPS_USER@$VPS_HOST" "docker network create reverse-proxy 2>/dev/null || echo 'Network already exists'"

# Step 6: Deploy container
echo -e "${YELLOW}[6/6] Starting staging container...${NC}"
ssh "$VPS_USER@$VPS_HOST" "cd $DEPLOY_PATH && docker-compose -f docker-compose.yml -f docker-compose.staging.yml up -d"

# Clean up local tarball
rm grumpygoose-staging.tar.gz

echo ""
echo -e "${GREEN}✓ Staging deployment complete!${NC}"
echo ""
echo "To view logs:"
echo "  ssh $VPS_USER@$VPS_HOST 'docker logs -f grumpygoose-staging'"
echo ""
echo "To check container status:"
echo "  ssh $VPS_USER@$VPS_HOST 'docker ps | grep grumpygoose'"
echo ""
echo -e "${YELLOW}Note: You'll need to configure DNS and reverse proxy to access the site.${NC}"
