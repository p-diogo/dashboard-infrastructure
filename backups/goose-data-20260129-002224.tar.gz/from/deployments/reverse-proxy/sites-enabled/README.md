# Sites Configuration Directory

This directory contains Caddy site configurations that are automatically included by the main Caddyfile.

## How to Add a New Site

When deploying a new Docker container that needs to be accessible via the reverse proxy, add a `.Caddyfile` here with your site configuration.

## Example: grumpygoose-staging.Caddyfile

```
staging-grump.your-domain.com {
    import common

    reverse_proxy grumpygoose-staging:8080 {
        header_up X-Real-IP {remote_host}
        header_up X-Forwarded-For {remote_host}
        header_up X-Forwarded-Proto {scheme}
    }
}
```

## Example: grumpygoose-production.Caddyfile

```
grump.your-domain.com {
    import common

    reverse_proxy grumpygoose-prod:8080 {
        header_up X-Real-IP {remote_host}
        header_up X-Forwarded-For {remote_host}
        header_up X-Forwarded-Proto {scheme}
    }
}
```

## Auto-Discovery via Docker Labels

The Caddy container can auto-discover services via Docker labels. When you start your app containers, add these labels:

```yaml
labels:
  - "caddy.address=your-domain.com"
  - "caddy.port=8080"
  - "caddy.reverse_proxy={{upstreams}}"
  - "caddy.import.common"
```

Caddy will automatically configure routing for these containers.

## Notes

- Files must end with `.Caddyfile` extension to be imported
- The `import common` directive adds security headers, compression, and logging
- Make sure the container name matches the reverse_proxy target (e.g., `grumpygoose-staging:8080`)
- All containers must be on the `reverse-proxy` Docker network
