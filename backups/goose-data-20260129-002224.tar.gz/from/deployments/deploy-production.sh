#!/bin/bash
# Deploy grumpygoose to production environment

set -e  # Exit on error

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configuration
VPS_HOST="${VPS_HOST:-}"
VPS_USER="${VPS_USER:-root}"
DEPLOY_PATH="/opt/grumpygoose-prod"
VERSION="${VERSION:-$(git rev-parse --short HEAD)}"
DOCKER_IMAGE="grumpygoose:$VERSION"

echo -e "${BLUE}==================================================${NC}"
echo -e "${BLUE}🪿 GRUMPY GOOSE - Production Deployment${NC}"
echo -e "${BLUE}==================================================${NC}"
echo ""
echo -e "Version: ${GREEN}$VERSION${NC}"
echo ""

# Check if VPS_HOST is set
if [ -z "$VPS_HOST" ]; then
    echo -e "${RED}Error: VPS_HOST environment variable not set${NC}"
    echo "Usage: VPS_HOST=your-vps.com VERSION=v1.2.3 ./deploy-production.sh"
    exit 1
fi

# Confirm deployment
echo -e "${YELLOW}This will deploy to PRODUCTION. Are you sure?${NC}"
read -p "Type 'yes' to continue: " confirmation
if [ "$confirmation" != "yes" ]; then
    echo -e "${RED}Deployment cancelled${NC}"
    exit 0
fi

# Step 1: Build Docker image locally
echo -e "${YELLOW}[1/8] Building Docker image locally...${NC}"
docker build -t "$DOCKER_IMAGE" .
docker tag "$DOCKER_IMAGE" grumpygoose:latest

# Step 2: Save image to tarball
echo -e "${YELLOW}[2/8] Exporting Docker image...${NC}"
docker save "$DOCKER_IMAGE" | gzip > grumpygoose-production.tar.gz

# Step 3: Backup production database on VPS
echo -e "${YELLOW}[3/8] Backing up production database...${NC}"
ssh "$VPS_USER@$VPS_HOST" "
    if [ -f $DEPLOY_PATH/data/goose.db ]; then
        cp $DEPLOY_PATH/data/goose.db $DEPLOY_PATH/data/goose.db.backup.\$(date +%Y%m%d_%H%M%S)
        echo 'Database backed up'
    else
        echo 'No existing database to backup'
    fi
"

# Step 4: Copy files to VPS
echo -e "${YELLOW}[4/8] Copying files to VPS...${NC}"
ssh "$VPS_USER@$VPS_HOST" "mkdir -p $DEPLOY_PATH"
scp grumpygoose-production.tar.gz "$VPS_USER@$VPS_HOST:$DEPLOY_PATH/"
scp docker-compose.yml "$VPS_USER@$VPS_HOST:$DEPLOY_PATH/"
scp docker-compose.prod.yml "$VPS_USER@$VPS_HOST:$DEPLOY_PATH/"
scp .env.production "$VPS_USER@$VPS_HOST:$DEPLOY_PATH/.env" 2>/dev/null || echo "# No .env.production file, skipping"

# Step 5: Load image on VPS
echo -e "${YELLOW}[5/8] Loading Docker image on VPS...${NC}"
ssh "$VPS_USER@$VPS_HOST" "cd $DEPLOY_PATH && docker load < grumpygoose-production.tar.gz"

# Step 6: Stop old container
echo -e "${YELLOW}[6/8] Stopping old container...${NC}"
ssh "$VPS_USER@$VPS_HOST" "cd $DEPLOY_PATH && docker-compose -f docker-compose.yml -f docker-compose.prod.yml down || echo 'No old container to stop'"

# Step 7: Start new container
echo -e "${YELLOW}[7/8] Starting new container...${NC}"
ssh "$VPS_USER@$VPS_HOST" "cd $DEPLOY_PATH && VERSION=$VERSION docker-compose -f docker-compose.yml -f docker-compose.prod.yml up -d"

# Step 8: Clean up
echo -e "${YELLOW}[8/8] Cleaning up...${NC}"
rm grumpygoose-production.tar.gz
ssh "$VPS_USER@$VPS_HOST" "rm $DEPLOY_PATH/grumpygoose-production.tar.gz"

echo ""
echo -e "${GREEN}✓ Production deployment complete!${NC}"
echo ""
echo "To view logs:"
echo "  ssh $VPS_USER@$VPS_HOST 'docker logs -f grumpygoose-prod'"
echo ""
echo "To check container status:"
echo "  ssh $VPS_USER@$VPS_HOST 'docker ps | grep grumpygoose'"
echo ""
echo "To rollback:"
echo "  ssh $VPS_USER@$VPS_HOST 'cd $DEPLOY_PATH && docker-compose down && cp data/goose.db.backup.YYYYMMDD_HHMMSS data/goose.db && docker-compose up -d'"
echo ""
