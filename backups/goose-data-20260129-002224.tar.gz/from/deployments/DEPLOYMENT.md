# GrumpyGoose Deployment Guide

Complete guide for deploying grumpygoose with Docker, including staging/production environments and automatic HTTPS via Caddy reverse proxy.

---

## Table of Contents

1. [Architecture Overview](#architecture-overview)
2. [Prerequisites](#prerequisites)
3. [Initial VPS Setup](#initial-vps-setup)
4. [DNS Configuration](#dns-configuration)
5. [Deploying Staging](#deploying-staging)
6. [Setting Up Reverse Proxy](#setting-up-reverse-proxy)
7. [Deploying Production](#deploying-production)
8. [Monitoring & Maintenance](#monitoring--maintenance)
9. [Troubleshooting](#troubleshooting)

---

## Architecture Overview

```
┌─────────────────────────────────────────────────────────────────┐
│                         Your VPS                                │
├─────────────────────────────────────────────────────────────────┤
│                                                                   │
│  ┌─────────────────────────────────────────────────────────┐    │
│  │              Caddy Reverse Proxy (Port 80/443)          │    │
│  │  - Automatic HTTPS (Let's Encrypt)                      │    │
│  │  - Routing to multiple containers                       │    │
│  │  - Security headers & compression                       │    │
│  └────────────────────┬────────────────────────────────────┘    │
│                       │                                          │
│                       ▼                                          │
│  ┌──────────────────────────────────────────────────────────┐   │
│  │              Docker Network: reverse-proxy               │   │
│  ├──────────────────────┬───────────────────────────────────┤   │
│  │                      │                                   │   │
│  ▼                      ▼                                   │   │
│  ┌──────────────────┐  ┌──────────────────┐                │   │
│  │   grumpygoose    │  │   grumpygoose    │                │   │
│  │    -staging      │  │     -prod        │                │   │
│  │   (Port 8080)    │  │   (Port 8080)    │                │   │
│  └──────────────────┘  └──────────────────┘                │   │
│                                                          │   │
│  ┌──────────────────┐  ┌──────────────────┐                │   │
│  │   Other App 1    │  │   Other App 2    │  ...           │   │
│  └──────────────────┘  └──────────────────┘                │   │
│                                                         │    │
└─────────────────────────────────────────────────────────────┘
```

**Key Features:**
- **Docker-based**: All services run in containers
- **Staging & Production**: Separate environments with Docker tags
- **Automatic HTTPS**: Caddy handles Let's Encrypt certificates automatically
- **Multi-app support**: Reverse proxy can handle multiple applications
- **Persistent volumes**: Database and output preserved across deployments

---

## Prerequisites

### On Your Local Machine
- Docker installed
- SSH access to your VPS
- Git

### On Your VPS
- Fresh installation of:
  - Docker
  - Docker Compose
- Root or sudo access
- Ports 80 and 443 open

### Domain
- A domain name (e.g., `your-domain.com`)
- Ability to add DNS records

---

## Initial VPS Setup

### 1. Install Docker on VPS

```bash
# SSH into your VPS
ssh root@your-vps-ip

# Update system
apt-get update && apt-get upgrade -y

# Install Docker
curl -fsSL https://get.docker.com -o get-docker.sh
sh get-docker.sh

# Install Docker Compose
curl -L "https://github.com/docker/compose/releases/latest/download/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
chmod +x /usr/local/bin/docker-compose

# Verify installation
docker --version
docker-compose --version

# Create Docker network for reverse proxy
docker network create reverse-proxy
```

### 2. Set Up Firewall (Optional but Recommended)

```bash
# Install UFW
apt-get install -y ufw

# Allow SSH
ufw allow 22/tcp

# Allow HTTP/HTTPS
ufw allow 80/tcp
ufw allow 443/tcp

# Enable firewall
ufw enable

# Check status
ufw status
```

---

## DNS Configuration

Before deploying, you need to set up DNS records. You'll need:

### For Staging
- **A Record**: `staging-grump.your-domain.com` → `your-vps-ip`

### For Production
- **A Record**: `grump.your-domain.com` → `your-vps-ip`

### Example (Cloudflare, Namecheap, etc.)

| Type | Name | Value | TTL |
|------|------|-------|-----|
| A | staging-grump | `your-vps-ip` | 3600 |
| A | grump | `your-vps-ip` | 3600 |

**Note**: DNS propagation can take up to 24 hours, but usually completes within minutes.

---

## Deploying Staging

### Step 1: Set Environment Variables

```bash
# On your local machine
cd /Users/pdiogo/Documents/code/thegraph/grumpygoose

export VPS_HOST="your-vps-ip"
export VPS_USER="root"  # or your username
```

### Step 2: Run Deployment Script

```bash
./deployments/deploy-staging.sh
```

This will:
1. Build the Docker image locally
2. Copy it to the VPS
3. Start the staging container

### Step 3: Verify Staging Deployment

```bash
# SSH into VPS
ssh root@$VPS_HOST

# Check container is running
docker ps | grep grumpygoose

# View logs
docker logs -f grumpygoose-staging

# Check generated files
docker exec grumpygoose-staging ls -la /app/output/
```

### Step 4: Test Without DNS (Temporary)

If DNS isn't set up yet, you can test by accessing the container directly:

```bash
# On VPS, get the container IP
docker inspect grumpygoose-staging | grep IPAddress

# Or use port forwarding from your local machine
ssh -L 8080:localhost:8080 root@$VPS_HOST
# Then visit: http://localhost:8080
```

---

## Setting Up Reverse Proxy

Once staging is running and DNS is configured, set up Caddy for automatic HTTPS.

### Step 1: Create Deployment Directory on VPS

```bash
ssh root@$VPS_HOST

# Create reverse-proxy directory
mkdir -p /opt/reverse-proxy/sites-enabled
cd /opt/reverse-proxy
```

### Step 2: Copy Caddy Configuration

```bash
# From your local machine
cd /Users/pdiogo/Documents/code/thegraph/grumpygoose

scp -r deployments/reverse-proxy/* root@$VPS_HOST:/opt/reverse-proxy/
```

### Step 3: Configure Email for SSL

```bash
# On VPS
cd /opt/reverse-proxy

# Set your email for Let's Encrypt notifications
export ADMIN_EMAIL="your-email@your-domain.com"
```

### Step 4: Create Staging Site Config

```bash
# On VPS
cd /opt/reverse-proxy/sites-enabled

# Create staging configuration
cat > staging-grump.Caddyfile << 'EOF'
staging-grump.your-domain.com {
    import common

    reverse_proxy grumpygoose-staging:8080 {
        header_up X-Real-IP {remote_host}
        header_up X-Forwarded-For {remote_host}
        header_up X-Forwarded-Proto {scheme}
    }
}
EOF

# Replace your-domain.com with your actual domain
sed -i 's/your-domain.com/your-actual-domain.com/g' staging-grump.Caddyfile
```

### Step 5: Start Caddy

```bash
# On VPS, in /opt/reverse-proxy
docker-compose up -d

# Check Caddy logs
docker logs -f caddy-reverse-proxy

# You should see Caddy obtaining SSL certificates
```

### Step 6: Access Staging via HTTPS

Visit: `https://staging-grump.your-domain.com`

You should see:
- ✅ HTTPS with valid certificate
- ✅ GrumpyGoose dashboard with both Safes displayed
- ✅ No browser security warnings

---

## Deploying Production

Once staging is verified, deploy to production.

### Step 1: Set Environment Variables

```bash
# On your local machine
export VPS_HOST="your-vps-ip"
export VPS_USER="root"
export VERSION="v1.0.0"  # Or use git commit hash
```

### Step 2: Run Production Deployment

```bash
./deployments/deploy-production.sh
```

This will:
1. Build and tag production image
2. **Backup existing production database**
3. Deploy new version
4. Prompt for confirmation before proceeding

### Step 3: Add Production to Reverse Proxy

```bash
# On VPS
cd /opt/reverse-proxy/sites-enabled

cat > grump.Caddyfile << 'EOF'
grump.your-domain.com {
    import common

    reverse_proxy grumpygoose-prod:8080 {
        header_up X-Real-IP {remote_host}
        header_up X-Forwarded-For {remote_host}
        header_up X-Forwarded-Proto {scheme}
    }
}
EOF

# Replace your-domain.com with your actual domain
sed -i 's/your-domain.com/your-actual-domain.com/g' grump.Caddyfile

# Reload Caddy
docker restart caddy-reverse-proxy
```

### Step 4: Verify Production

Visit: `https://grump.your-domain.com`

Check:
- ✅ HTTPS working
- ✅ Data is populated
- ✅ Both Safes showing metrics
- ✅ No errors in logs

---

## Monitoring & Maintenance

### View Logs

```bash
# Staging logs
ssh root@$VPS_HOST 'docker logs -f grumpygoose-staging'

# Production logs
ssh root@$VPS_HOST 'docker logs -f grumpygoose-prod'

# Caddy logs (reverse proxy)
ssh root@$VPS_HOST 'docker logs -f caddy-reverse-proxy'

# All container logs
ssh root@$VPS_HOST 'docker ps -q | xargs -I {} docker logs --tail 50 {}'
```

### Check Container Status

```bash
ssh root@$VPS_HOST << 'EOF'
echo "=== GrumpyGoose Containers ==="
docker ps | grep grumpygoose

echo ""
echo "=== Container Resources ==="
docker stats --no-stream grumpygoose-staging grumpygoose-prod
EOF
```

### Database Backups

```bash
# Manual backup
ssh root@$VPS_HOST 'docker exec grumpygoose-prod cp /app/data/goose.db /app/data/goose.db.backup.$(date +%Y%m%d)'

# List backups
ssh root@$VPS_HOST 'docker exec grumpygoose-prod ls -la /app/data/*.backup.*'

# Download backup locally
scp root@$VPS_HOST:/opt/grumpygoose-prod/data/goose.db.backup.YYYYMMDD ./local-backup.db
```

### Update Container

```bash
# Re-deploy staging
cd /Users/pdiogo/Documents/code/thegraph/grumpygoose
./deployments/deploy-staging.sh

# Re-deploy production (after verifying staging)
export VERSION="v1.0.1"
./deployments/deploy-production.sh
```

### Restart Container

```bash
ssh root@$VPS_HOST 'docker restart grumpygoose-staging'
# or
ssh root@$VPS_HOST 'docker restart grumpygoose-prod'
```

---

## Troubleshooting

### Container Won't Start

```bash
# Check logs
ssh root@$VPS_HOST 'docker logs grumpygoose-staging'

# Check if port is already in use
ssh root@$VPS_HOST 'netstat -tlnp | grep 8080'

# Check container status
ssh root@$VPS_HOST 'docker ps -a | grep grumpygoose'
```

### Database Migration Issues

```bash
# SSH into container
ssh root@$VPS_HOST 'docker exec -it grumpygoose-staging bash'

# Inside container, check database
ls -la /app/data/
sqlite3 /app/data/goose.db ".schema transactions"
sqlite3 /app/data/goose.db "SELECT * FROM schema_migrations"

# Run migrations manually
python /app/migrations.py
```

### HTTPS/SSL Certificate Issues

```bash
# Check Caddy logs for certificate errors
ssh root@$VPS_HOST 'docker logs caddy-reverse-proxy | grep -i error'

# Verify DNS is pointing correctly
dig staging-grump.your-domain.com
dig grump.your-domain.com

# Check Caddy data
ssh root@$VPS_HOST 'docker exec caddy-reverse-proxy ls -la /data/certificates/'
```

### Data Not Showing Up

```bash
# Check if data collection ran
ssh root@$VPS_HOST 'docker logs grumpygoose-staging | grep "Fetching"'

# Verify database has data
ssh root@$VPS_HOST 'docker exec grumpygoose-staging sqlite3 /app/data/goose.db "SELECT COUNT(*) FROM transactions"'

# Check output file exists
ssh root@$VPS_HOST 'docker exec grumpygoose-staging ls -la /app/output/index.html'
```

### Rollback Production

If something goes wrong:

```bash
ssh root@$VPS_HOST << 'EOF'
cd /opt/grumpygoose-prod

# Stop current container
docker-compose down

# Restore from backup (list backups first)
ls -lt data/goose.db.backup.*
cp data/goose.db.backup.YYYYMMDD_HHMMSS data/goose.db

# Restart
docker-compose up -d
EOF
```

---

## Quick Reference Commands

```bash
# Deploy staging
VPS_HOST=your-vps-ip ./deployments/deploy-staging.sh

# Deploy production
VPS_HOST=your-vps-ip VERSION=v1.0.0 ./deployments/deploy-production.sh

# View logs
ssh root@your-vps-ip 'docker logs -f grumpygoose-staging'

# Restart container
ssh root@your-vps-ip 'docker restart grumpygoose-staging'

# Check status
ssh root@your-vps-ip 'docker ps | grep grumpygoose'

# Database backup
ssh root@your-vps-ip 'docker exec grumpygoose-prod cp /app/data/goose.db /app/data/goose.db.backup.$(date +%Y%m%d)'

# Access container shell
ssh root@your-vps-ip 'docker exec -it grumpygoose-staging bash'
```

---

## Next Steps After Initial Deployment

1. **Verify Staging**
   - [ ] Visit https://staging-grump.your-domain.com
   - [ ] Check both Safes are showing data
   - [ ] Verify metrics are calculating correctly
   - [ ] Check browser console for errors

2. **Set Up Monitoring** (Optional)
   - Install a monitoring solution (e.g., Uptime Kuma, Grafana)
   - Set up alerts for container downtime
   - Monitor disk usage

3. **Configure Backups**
   - Set up automated database backups to offsite storage
   - Test restore procedure

4. **Deploy to Production**
   - [ ] Run production deployment script
   - [ ] Verify production is working
   - [ ] Add to reverse proxy
   - [ ] Update production DNS

5. **Document Your Setup**
   - Save VPS credentials securely
   - Document your specific domain names
   - Keep track of deployed versions
