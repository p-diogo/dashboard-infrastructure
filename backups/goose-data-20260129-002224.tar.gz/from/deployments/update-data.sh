#!/bin/bash
# Simple script to update grumpygoose data
# Run this periodically via cron or manually

set -e

CONTAINER_NAME="${1:-grumpygoose-staging}"

echo "[$(date)] Updating grumpygoose data in $CONTAINER_NAME..."

# Fetch new data
docker exec "$CONTAINER_NAME" python setup.py

# Regenerate dashboard
docker exec "$CONTAINER_NAME" python generate_static.py

echo "[$(date)] Update complete!"
echo "Dashboard refreshed at: https://staging-grump.your-domain.com"
