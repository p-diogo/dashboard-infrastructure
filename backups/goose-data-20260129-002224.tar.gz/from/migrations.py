"""
Migration framework for grumpygoose database
Tracks schema versions and applies migrations incrementally
"""

import sqlite3
from datetime import datetime
import config

# Migration versions
MIGRATIONS = {
    1: "Initial schema (proposals, transactions, votes, members)",
    2: "Add safe_address column to transactions table",
    3: "Add safes table for multi-safe configuration",
    4: "Add sync_state table for incremental updates",
}


def get_current_version(conn):
    """Get current migration version"""
    cursor = conn.cursor()
    cursor.execute("""
        SELECT name FROM sqlite_master
        WHERE type='table' AND name='schema_migrations'
    """)

    if not cursor.fetchone():
        # Create schema_migrations table
        cursor.execute("""
            CREATE TABLE schema_migrations (
                version INTEGER PRIMARY KEY,
                applied_at INTEGER
            )
        """)
        conn.commit()
        return 0  # No migrations have been applied yet

    cursor.execute("SELECT MAX(version) FROM schema_migrations")
    return cursor.fetchone()[0] or 0


def apply_migration_1_to_2(conn):
    """Migration: Add safe_address column to transactions table"""
    cursor = conn.cursor()

    # Check if transactions table exists (might not in fresh database)
    cursor.execute("""
        SELECT name FROM sqlite_master
        WHERE type='table' AND name='transactions'
    """)
    if not cursor.fetchone():
        print("  - transactions table doesn't exist yet (will be created by init_db)")
        conn.commit()
        return

    # Check if column already exists
    cursor.execute("PRAGMA table_info(transactions)")
    columns = [col[1] for col in cursor.fetchall()]

    if 'safe_address' not in columns:
        cursor.execute("""
            ALTER TABLE transactions
            ADD COLUMN safe_address TEXT
        """)
        # Set default for existing rows
        default_safe = "0x8C6de8F8D562f3382417340A6994601eE08D3809"
        cursor.execute(f"""
            UPDATE transactions
            SET safe_address = '{default_safe}'
            WHERE safe_address IS NULL
        """)
        print("  ✓ Added safe_address column to transactions table")
    else:
        print("  - safe_address column already exists")

    conn.commit()


def apply_migration_2_to_3(conn):
    """Migration: Add safes table for configuration tracking"""
    cursor = conn.cursor()

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS safes (
            address TEXT PRIMARY KEY,
            chain TEXT,
            label TEXT,
            api_url TEXT,
            created_at INTEGER
        )
    """)
    print("  ✓ Created safes table")

    conn.commit()


def apply_migration_3_to_4(conn):
    """Migration: Add sync_state table for incremental updates"""
    cursor = conn.cursor()

    # Check if table already exists
    cursor.execute("""
        SELECT name FROM sqlite_master
        WHERE type='table' AND name='sync_state'
    """)

    if not cursor.fetchone():
        cursor.execute("""
            CREATE TABLE sync_state (
                platform TEXT PRIMARY KEY,
                last_sync INTEGER,
                last_item_count INTEGER
            )
        """)
        print("  ✓ Created sync_state table")

        # Initialize sync state for platforms
        cursor.execute("""
            INSERT OR IGNORE INTO sync_state (platform, last_sync, last_item_count)
            VALUES ('snapshot', 0, 0)
        """)
        cursor.execute("""
            INSERT OR IGNORE INTO sync_state (platform, last_sync, last_item_count)
            VALUES ('safe', 0, 0)
        """)
        print("  ✓ Initialized sync_state for platforms")
    else:
        print("  - sync_state table already exists")

    conn.commit()


def run_migrations():
    """Run all pending migrations"""
    conn = sqlite3.connect(config.DATABASE_PATH)
    current_version = get_current_version(conn)
    latest_version = max(MIGRATIONS.keys())

    if current_version < latest_version:
        print(f"Running migrations: v{current_version} -> v{latest_version}")

        for version in range(current_version + 1, latest_version + 1):
            print(f"  Applying migration {version}...")

            if version == 2:
                apply_migration_1_to_2(conn)
            elif version == 3:
                apply_migration_2_to_3(conn)
            elif version == 4:
                apply_migration_3_to_4(conn)

            # Record migration
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO schema_migrations (version, applied_at)
                VALUES (?, ?)
            """, (version, int(datetime.now().timestamp())))
            conn.commit()

        print(f"✓ Migrations complete (version {latest_version})")
    else:
        print(f"Database up to date (version {current_version})")

    conn.close()


if __name__ == "__main__":
    run_migrations()
