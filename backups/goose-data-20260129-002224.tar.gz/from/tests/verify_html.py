#!/usr/bin/env python3
"""
Simple HTML verification script for GrumpyGoose dashboard
Validates that the generated HTML contains expected elements
"""

import os
import sys
from pathlib import Path

# Add parent directory to path for imports
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from config import OUTPUT_DIR


def verify_html_output():
    """Verify the generated HTML contains expected elements"""
    html_path = os.path.join(OUTPUT_DIR, 'index.html')
    
    if not os.path.exists(html_path):
        print(f"❌ HTML file not found: {html_path}")
        return False
    
    with open(html_path, 'r') as f:
        html_content = f.read()
    
    checks = [
        ("Snapshot Proposals card", "Snapshot Proposals", "Should have Snapshot Proposals card"),
        ("Safe Transactions card", "Safe Transactions", "Should have Safe Transactions card"),
        ("Total Governance Items card", "Total Governance Items", "Should have Total Governance Items card"),
        ("Total Votes & Signatures card", "Total Votes", "Should have Total Votes & Signatures card"),
        ("Active Items section", "Active Items Requiring Action", "Should have Active Items section"),
        ("Summary cards container", 'summary-cards', "Should have summary-cards container"),
        ("Leaderboard section", "Leaderboard", "Should have Leaderboard section"),
        ("Votes terminology", "votes", "Should use 'votes' terminology"),
        ("Signed terminology", "signed", "Should use 'signed' terminology"),
        ("Time to Quorum section", "Time to Quorum", "Should have Time to Quorum section"),
    ]
    
    all_passed = True
    
    print("=" * 60)
    print("🪿 GRUMPY GOOSE - HTML Verification")
    print("=" * 60)
    
    for name, search_term, description in checks:
        if search_term in html_content:
            print(f"✅ {name}: Found")
        else:
            print(f"❌ {name}: Missing - {description}")
            all_passed = False
    
    # Count summary cards
    import re
    card_pattern = r'<div class="card">'
    card_count = len(re.findall(card_pattern, html_content))
    print(f"\n📊 Summary cards found: {card_count}")
    if card_count == 4:
        print("✅ Expected 4 summary cards")
    else:
        print(f"❌ Expected 4 summary cards, found {card_count}")
        all_passed = False
    
    # Check for active items
    active_item_pattern = r'<div class="active-item '
    active_item_count = len(re.findall(active_item_pattern, html_content))
    print(f"\n⚠️  Active items found: {active_item_count}")
    if active_item_count >= 0:
        print(f"✅ Active Items section present")
    else:
        print(f"❌ No active items found")
        all_passed = False
    
    # Check file size
    file_size = os.path.getsize(html_path) / 1024
    print(f"\n📁 HTML file size: {file_size:.1f} KB")
    
    print("\n" + "=" * 60)
    if all_passed:
        print("✅ All checks passed!")
        return True
    else:
        print("❌ Some checks failed")
        return False


if __name__ == "__main__":
    success = verify_html_output()
    sys.exit(0 if success else 1)
