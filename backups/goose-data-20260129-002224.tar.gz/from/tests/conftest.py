"""
Pytest configuration and fixtures for grumpygoose tests
"""

import pytest
import sqlite3
import tempfile
import os
import sys

# Add parent directory to path for imports
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))


@pytest.fixture
def temp_db():
    """Provide a temporary database for each test"""
    fd, path = tempfile.mkstemp(suffix='.db')
    os.close(fd)

    # Override DATABASE_PATH
    import config
    original_db_path = config.DATABASE_PATH
    config.DATABASE_PATH = path

    # Make sure we start with a clean database
    # (Delete the file if it exists from a previous test run)
    if os.path.exists(path):
        os.unlink(path)

    yield path

    # Cleanup
    if os.path.exists(path):
        os.unlink(path)
    config.DATABASE_PATH = original_db_path


@pytest.fixture
def mock_safe_response():
    """Mock Safe API response with sample data"""
    return {
        "results": [
            {
                "safeTxHash": "0x1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef",
                "nonce": 1,
                "submissionDate": "2024-01-01T00:00:00Z",
                "executionDate": "2024-01-02T00:00:00Z",
                "confirmations": [
                    {"owner": "0xaaa0000000000000000000000000000000000001", "submissionDate": "2024-01-01T01:00:00Z"},
                    {"owner": "0xaaa0000000000000000000000000000000000002", "submissionDate": "2024-01-01T02:00:00Z"},
                    {"owner": "0xaaa0000000000000000000000000000000000003", "submissionDate": "2024-01-01T03:00:00Z"},
                    {"owner": "0xaaa0000000000000000000000000000000000004", "submissionDate": "2024-01-01T04:00:00Z"},
                    {"owner": "0xaaa0000000000000000000000000000000000005", "submissionDate": "2024-01-01T05:00:00Z"},
                    {"owner": "0xaaa0000000000000000000000000000000000006", "submissionDate": "2024-01-01T06:00:00Z"},
                ]
            }
        ]
    }


@pytest.fixture
def sample_safe_config():
    """Sample Safe configuration for testing"""
    return {
        "address": "0x8C6de8F8D562f3382417340A6994601eE08D3809",
        "chain": "arbitrum",
        "api_url": "https://safe-transaction-arbitrum.safe.global/api/v1",
        "label": "Arbitrum Council"
    }
