#!/bin/bash
# Production deployment script for grumpygoose
# Run this on your VPS to deploy the latest version
#
# Architecture:
#   - nginx: Serves static HTML files
#   - grumpygoose: One-shot container (generates initial HTML)
#   - grumpygoose-scheduler: Continuous (fetches data, regenerates HTML, sends alerts)

set -e

# Configuration
REGISTRY="ghcr.io/graphprotocol/grumpygoose"
VERSION=${VERSION:-latest}
COMPOSE_FILES="-f docker-compose.yml -f docker-compose.prod.yml"

echo "🪿 GOOSE Production Deployment"
echo "================================"
echo "Version: $VERSION"
echo "Registry: $REGISTRY"
echo ""

# Check if .env exists
if [ ! -f .env ]; then
    echo "❌ Error: .env file not found!"
    echo "Please create .env with production configuration"
    exit 1
fi

# Check if nginx.conf exists
if [ ! -f nginx.conf ]; then
    echo "❌ Error: nginx.conf not found!"
    echo "Please ensure nginx.conf is in the deployment directory"
    exit 1
fi

echo "✅ .env file found"
echo "✅ nginx.conf found"

# Pull latest image
echo ""
echo "📥 Pulling image $REGISTRY:$VERSION..."
docker pull "$REGISTRY:$VERSION"

# Stop existing containers
echo ""
echo "🛑 Stopping existing containers..."
docker compose $COMPOSE_FILES --profile scheduler-prod down

# Start new containers
echo ""
echo "🚀 Starting production containers..."
docker compose $COMPOSE_FILES --profile scheduler-prod up -d

# Wait for nginx to be healthy
echo ""
echo "⏳ Waiting for nginx to start..."
sleep 5

# Show status
echo ""
echo "📊 Container status:"
docker compose $COMPOSE_FILES ps

echo ""
echo "✅ Deployment complete!"
echo ""
echo "📝 View all logs:"
echo "   docker compose $COMPOSE_FILES --profile scheduler-prod logs -f"
echo ""
echo "🔍 Check scheduler:"
echo "   docker compose $COMPOSE_FILES --profile scheduler-prod logs -f grumpygoose-scheduler-prod"
echo ""
echo "🌐 Dashboard is served by nginx at http://grump.thegraph.foundation"
