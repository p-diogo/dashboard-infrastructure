"""
Simple HTTP server for grumpygoose dashboard
Serves static files and provides an API endpoint to trigger data updates
"""

import os
import sqlite3
import subprocess
import threading
import sys
from datetime import datetime
from http.server import HTTPServer, SimpleHTTPRequestHandler
import json

from config import DATABASE_PATH, OUTPUT_DIR
import alerts

# Track if an update is currently running
update_status = {
    "running": False,
    "last_started": None,
    "last_finished": None,
    "last_result": None,
    "logs": []
}

# Track alert status
alert_status = {
    "last_check": None,
    "last_alert_count": 0,
    "last_alert_items": [],
    "check_running": False
}


class GrumpyGooseHandler(SimpleHTTPRequestHandler):
    """Custom HTTP handler that serves static files and provides update API"""

    def do_GET(self):
        """Handle GET requests"""

        # Serve the API endpoints
        if self.path == '/api/status':
            self.send_api_status()
        elif self.path == '/api/last-update':
            self.send_last_update_info()
        elif self.path == '/api/alert-status':
            self.send_alert_status()
        elif self.path == '/':
            # Serve index.html
            self.path = '/index.html'
            return SimpleHTTPRequestHandler.do_GET(self)
        elif self.path.startswith('/api/'):
            self.send_json_response({"error": "Unknown endpoint"}, 404)
        else:
            # Serve static files
            return SimpleHTTPRequestHandler.do_GET(self)

    def do_POST(self):
        """Handle POST requests"""

        if self.path == '/api/update':
            self.trigger_update()
        elif self.path == '/api/check-alerts':
            self.trigger_alert_check()
        else:
            self.send_json_response({"error": "Unknown endpoint"}, 404)

    def send_json_response(self, data, status=200):
        """Send JSON response"""
        self.send_response(status)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Access-Control-Allow-Origin', '*')
        self.end_headers()
        self.wfile.write(json.dumps(data).encode())

    def send_api_status(self):
        """Send current update status"""
        # Get database stats
        stats = self.get_database_stats()

        self.send_json_response({
            "update_running": update_status["running"],
            "last_started": update_status["last_started"],
            "last_finished": update_status["last_finished"],
            "last_result": update_status["last_result"],
            "database": stats,
            "current_time": datetime.now().isoformat()
        })

    def send_last_update_info(self):
        """Send information about when data was last updated"""
        stats = self.get_database_stats()

        self.send_json_response({
            "last_transaction_time": stats.get("last_transaction_time"),
            "last_proposal_time": stats.get("last_proposal_time"),
            "total_transactions": stats.get("total_transactions", 0),
            "total_proposals": stats.get("total_proposals", 0),
            "current_time": datetime.now().isoformat()
        })

    def get_database_stats(self):
        """Get statistics from the database"""
        try:
            conn = sqlite3.connect(DATABASE_PATH)
            cursor = conn.cursor()

            # Count transactions and proposals
            cursor.execute("SELECT COUNT(*) FROM transactions")
            total_transactions = cursor.fetchone()[0]

            cursor.execute("SELECT COUNT(*) FROM proposals")
            total_proposals = cursor.fetchone()[0]

            # Get last transaction time
            cursor.execute("SELECT MAX(created_at) FROM transactions")
            last_tx = cursor.fetchone()[0]
            last_transaction_time = datetime.fromtimestamp(last_tx).isoformat() if last_tx else None

            # Get last proposal time
            cursor.execute("SELECT MAX(created_at) FROM proposals")
            last_proposal = cursor.fetchone()[0]
            last_proposal_time = datetime.fromtimestamp(last_proposal).isoformat() if last_proposal else None

            conn.close()

            return {
                "total_transactions": total_transactions,
                "total_proposals": total_proposals,
                "last_transaction_time": last_transaction_time,
                "last_proposal_time": last_proposal_time
            }
        except Exception as e:
            return {"error": str(e)}

    def trigger_update(self):
        """Trigger a background data update"""
        if update_status["running"]:
            self.send_json_response({
                "error": "Update already running",
                "started": update_status["last_started"]
            }, 409)
            return

        # Start update in background thread
        update_status["running"] = True
        update_status["last_started"] = datetime.now().isoformat()
        update_status["logs"] = []

        thread = threading.Thread(target=self.run_update)
        thread.daemon = True
        thread.start()

        self.send_json_response({
            "status": "Update started",
            "started_at": update_status["last_started"]
        })

    def run_update(self):
        """Run the data update in background"""
        try:
            # Change to app directory to run setup.py
            app_dir = os.path.dirname(os.path.abspath(__file__))

            # Run setup.py
            result = subprocess.run(
                [sys.executable, "setup.py"],
                cwd=app_dir,
                capture_output=True,
                text=True
            )

            # Run generate_static.py
            result2 = subprocess.run(
                [sys.executable, "generate_static.py"],
                cwd=app_dir,
                capture_output=True,
                text=True
            )

            if result.returncode == 0 and result2.returncode == 0:
                update_status["last_result"] = "success"
                update_status["logs"] = (result.stdout + result2.stdout).split('\n')
            else:
                update_status["last_result"] = f"error: {result.stderr} {result2.stderr}"
                update_status["logs"] = [result.stderr, result2.stderr]

        except Exception as e:
            update_status["last_result"] = f"error: {str(e)}"
            update_status["logs"] = [str(e)]
        finally:
            update_status["running"] = False
            update_status["last_finished"] = datetime.now().isoformat()

    def send_alert_status(self):
        """Send current alert status"""
        self.send_json_response({
            "last_check": alert_status["last_check"],
            "last_alert_count": alert_status["last_alert_count"],
            "last_alert_items": alert_status["last_alert_items"],
            "check_running": alert_status["check_running"],
            "current_time": datetime.now().isoformat()
        })

    def trigger_alert_check(self):
        """Trigger a background alert check"""
        if alert_status["check_running"]:
            self.send_json_response({
                "error": "Alert check already running"
            }, 409)
            return

        # Start alert check in background thread
        alert_status["check_running"] = True

        thread = threading.Thread(target=self.run_alert_check)
        thread.daemon = True
        thread.start()

        self.send_json_response({
            "status": "Alert check started",
            "started_at": datetime.now().isoformat()
        })

    def run_alert_check(self):
        """Run the alert check in background"""
        try:
            # Get active items (same as shown on frontend dashboard)
            items = alerts.get_active_items_for_alerts()

            # Update alert status
            alert_status["last_check"] = datetime.now().isoformat()
            alert_status["last_alert_count"] = len(items)
            alert_status["last_alert_items"] = items

            # Send Slack notification if there are items
            if items:
                alerts.send_slack_notification(alerts.format_slack_message(items))

        except Exception as e:
            print(f"Error during alert check: {e}")
            alert_status["last_alert_count"] = 0
            alert_status["last_alert_items"] = []
        finally:
            alert_status["check_running"] = False

    def log_message(self, format, *args):
        """Suppress default logging"""
        pass


def run_server(port=8080):
    """Run the HTTP server"""

    # Ensure output directory exists
    os.makedirs(OUTPUT_DIR, exist_ok=True)

    # Change to output directory so SimpleHTTPRequestHandler serves from there
    os.chdir(OUTPUT_DIR)

    with HTTPServer(("", port), GrumpyGooseHandler) as httpd:
        print(f"🪿 GrumpyGoose server running at http://localhost:{port}")
        print(f"   Dashboard: http://localhost:{port}/")
        print(f"   API status: http://localhost:{port}/api/status")
        print(f"   Trigger update: POST http://localhost:{port}/api/update")
        print(f"   Alert status: http://localhost:{port}/api/alert-status")
        print(f"   Check alerts: POST http://localhost:{port}/api/check-alerts")
        print(f"   Serving from: {OUTPUT_DIR}")
        print(f"\nPress Ctrl+C to stop")
        httpd.serve_forever()


if __name__ == "__main__":
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 8080
    run_server(port)
