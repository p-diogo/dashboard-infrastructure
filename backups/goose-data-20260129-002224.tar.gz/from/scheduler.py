#!/usr/bin/env python3
"""
GOOSE Scheduler - Self-contained cron scheduler

Runs two periodic tasks:
1. Data updates: Every 5 minutes (check for new proposals/signatures)
2. Alert checks: Every 2 days at 12:00 CET (only if active items exist)

This runs inside the Docker container - no external cron needed!
"""

import os
import sys
import time
import schedule
from datetime import datetime
from zoneinfo import ZoneInfo
import time as time_module

# Load environment variables
try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

# Get timezone from environment
TZ_NAME = os.environ.get('TZ', 'UTC')
try:
    TZ = ZoneInfo(TZ_NAME)
except Exception:
    print(f"Warning: Could not load timezone {TZ_NAME}, using UTC")
    TZ = ZoneInfo('UTC')

# Get scheduler cadence from environment
UPDATE_INTERVAL_MINUTES = int(os.environ.get('UPDATE_INTERVAL_MINUTES', '5'))
ALERT_INTERVAL_DAYS = int(os.environ.get('ALERT_INTERVAL_DAYS', '2'))
ALERT_TIME = os.environ.get('ALERT_TIME', '12:00')


def update_data():
    """Fetch new data from APIs (Snapshot and Safe) and regenerate HTML"""
    print(f"\n[{datetime.now(TZ).strftime('%Y-%m-%d %H:%M:%S %Z')}] 🔄 Checking for new data...")

    try:
        # Check for new data incrementally
        import incremental_update
        has_new_data = incremental_update.check_and_update_incremental()

        if has_new_data:
            print("✅ New data found and saved")

            # Regenerate HTML dashboard
            print("📄 Regenerating HTML dashboard...")
            import generate_static
            generate_static.main()
            print("✅ HTML dashboard regenerated")
        else:
            print("✅ No new data - skipping HTML regeneration")

    except Exception as e:
        print(f"❌ Data update failed: {e}")


def check_alerts():
    """Check for active items and send Slack alert if any exist"""
    print(f"\n[{datetime.now(TZ).strftime('%Y-%m-%d %H:%M:%S %Z')}] 🔔 Checking for active items...")
    try:
        from alerts import check_and_alert
        check_and_alert()
    except Exception as e:
        print(f"❌ Alert check failed: {e}")


def wait_for_db_ready(max_wait_seconds=600):
    """Wait for database to be initialized (HTML file exists and is recent)"""
    print("Checking if database is ready...")
    import config
    import time as time_module

    start_time = time_module.time()
    while time_module.time() - start_time < max_wait_seconds:
        try:
            # Check if HTML file exists and is RECENT (created within last 5 minutes)
            html_path = os.path.join(config.OUTPUT_DIR, 'index.html')
            if os.path.exists(html_path):
                file_age = time_module.time() - os.path.getmtime(html_path)
                if file_age < 300:  # File is less than 5 minutes old
                    print(f"  ✓ Database ready (HTML file found, {int(file_age)} seconds old)")
                    return True
                else:
                    print(f"  HTML file exists but is old ({int(file_age/60)} minutes ago) - waiting for fresh setup...")

            print(f"  Waiting for setup container to complete (looking for {html_path})...")
            time_module.sleep(10)
        except Exception as e:
            print(f"  Error: {e}")
            time_module.sleep(10)

    print("  ⚠️ Timeout waiting for database - proceeding anyway")
    return False


def run_scheduler():
    """Main scheduler loop"""
    print("=" * 60)
    print("🪿 GOOSE Scheduler Starting")
    print("=" * 60)
    print(f"Timezone: {TZ_NAME}")
    print(f"Current time: {datetime.now(TZ).strftime('%Y-%m-%d %H:%M:%S')}")
    print()

    # Schedule data updates with configurable interval
    schedule.every(UPDATE_INTERVAL_MINUTES).minutes.do(update_data)
    print(f"✓ Scheduled: Data update every {UPDATE_INTERVAL_MINUTES} minute(s)")

    # Schedule alert check with configurable interval and time
    schedule.every(ALERT_INTERVAL_DAYS).days.at(ALERT_TIME).do(check_alerts)
    print(f"✓ Scheduled: Alert check every {ALERT_INTERVAL_DAYS} day(s) at {ALERT_TIME}")

    # Log next run times
    print()
    print("Next runs:")
    for job in schedule.jobs:
        print(f"  - {job.job_func.__name__}: {job.next_run}")

    print()
    print("=" * 60)
    print("Scheduler is running. Press Ctrl+C to stop.")
    print("=" * 60)
    print()

    # Run initial data update on startup (full setup on first run)
    print("Running initial data update...")

    # Wait for database to be ready (one-shot container might still be running)
    db_ready = wait_for_db_ready(max_wait_seconds=300)

    if db_ready:
        try:
            # Database is ready - do incremental check
            print("Database exists - doing incremental check...")
            update_data()
        except Exception as e:
            print(f"Initial update failed: {e}")
    else:
        print("⏳ Database not ready yet - will try again on next scheduled run")

    print()

    # Initial alert check (but only sends if active items exist)
    print("Running initial alert check...")
    try:
        check_alerts()
    except Exception as e:
        # Alert check might fail if database not yet initialized
        if "no such table" in str(e):
            print("⏳ Alert check skipped - database not yet initialized")
        else:
            print(f"⚠️ Alert check failed: {e}")
    print()

    print("=" * 60)
    print("Scheduler loop started. Waiting for next scheduled job...")
    print("=" * 60)
    print()

    # Main loop
    while True:
        try:
            schedule.run_pending()
            time.sleep(10)  # Check every 10 seconds
        except KeyboardInterrupt:
            print("\n\nScheduler stopped by user")
            break
        except Exception as e:
            print(f"\n❌ Scheduler error: {e}")
            time.sleep(60)  # Wait 1 minute before continuing


if __name__ == "__main__":
    # Install schedule library if not available
    try:
        import schedule
    except ImportError:
        print("Installing 'schedule' library...")
        import subprocess
        subprocess.check_call([sys.executable, "-m", "pip", "install", "--break-system-packages", "schedule"])
        import schedule

    run_scheduler()
