"""
Alert system for governance items requiring attention
Sends Slack notifications for active Snapshot proposals and Safe transactions

MESSAGE TEMPLATE is in format_slack_message() - edit it to customize alerts
"""

import os
import requests
from datetime import datetime, timedelta
from typing import List, Dict, Optional
import config
from database import get_connection, get_member_display_name

# Load environment variables from .env file if it exists
try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass  # python-dotenv not installed, use system env vars


def get_active_items_for_alerts() -> List[Dict]:
    """
    Get active items from the frontend (matching Active Items section)

    Returns:
        List of active Snapshot proposals and Safe transactions that need attention
        Same data as shown on the frontend dashboard
    """
    from metrics import get_active_items
    return get_active_items()


def format_slack_message(items: List[Dict]) -> str:
    """
    MESSAGE TEMPLATE - Format active items as Slack message

    This shows the same information as the Active Items section on the web page:
    - Number of active proposals/transactions
    - Links to proposals/transactions
    - Who needs to vote/sign on which
    - Expiration date (Snapshot only)
    - When we got the last vote/signature
    - How long it's been open

    Args:
        items: List of active items from get_active_items()

    Returns:
        Formatted Slack message
    """
    if not items:
        return "✅ No active proposals or transactions requiring attention."

    # Count by type
    snapshot_count = sum(1 for item in items if item['type'] == 'snapshot')
    safe_count = sum(1 for item in items if item['type'] == 'safe')
    notion_count = sum(1 for item in items if item['type'] == 'notion')

    # Header
    lines = [
        "*GOOSE Alert*",
        f"{len(items)} item(s) need attention • 📸 {snapshot_count} Snapshot | 🔐 {safe_count} Safe | 📝 {notion_count} Notion\n",
        "───\n"
    ]

    for idx, item in enumerate(items):
        if item['type'] == 'snapshot':
            # Snapshot proposal
            title = item.get('title', 'Unknown Proposal')
            vote_count = item.get('vote_count', 0)
            days_open = item.get('days_open', 0)
            days_until_end = item.get('days_until_end', 0)

            # Get missing voters
            missing_voters = item.get('missing_voters', [])

            # Get last vote time
            voted_members = item.get('voted_members', [])
            last_vote_time = None
            if voted_members:
                last_vote_hours = voted_members[-1]['time_hours']
                days = int(last_vote_hours // 24)
                hours = int(last_vote_hours % 24)
                if days > 0:
                    last_vote_time = f"{days}d {hours}h ago"
                else:
                    last_vote_time = f"{hours}h ago"

            # Platform badge + title
            lines.append(f"*{idx + 1}. 📸 `Snapshot` • {title}*")
            lines.append(f"👉 <{item['url']}|View proposal>")

            # Status line
            status_parts = [f"{vote_count}/6 votes"]
            if days_until_end > 0:
                status_parts.append(f"expiring in {days_until_end:.0f} days")
            status_parts.append(f"open {days_open:.0f}d")
            lines.append(" • ".join(status_parts))

            if last_vote_time:
                lines.append(f"_Last vote {last_vote_time}_")

            # Actionable part - make it stand out!
            if missing_voters:
                lines.append("\n*MISSING VOTES:*")
                for voter in missing_voters:
                    lines.append(f"• {voter}")

        elif item['type'] == 'notion':
            # Notion proposal
            title = item.get('title', 'Unknown Proposal')
            vote_count = item.get('vote_count', 0)
            days_open = item.get('days_open', 0)
            days_until_end = item.get('days_until_end')

            # Get missing voters
            missing_voters = item.get('missing_voters', [])

            # Get last vote time
            voted_members = item.get('voted_members', [])
            last_vote_time = None
            if voted_members:
                last_vote_hours = voted_members[-1]['time_hours']
                days = int(last_vote_hours // 24)
                hours = int(last_vote_hours % 24)
                if days > 0:
                    last_vote_time = f"{days}d {hours}h ago"
                else:
                    last_vote_time = f"{hours}h ago"

            # Platform badge + title
            lines.append(f"*{idx + 1}. 📝 `Notion` • {title}*")
            lines.append(f"👉 <{item['url']}|View proposal>")

            # Status line
            status_parts = [f"{vote_count}/6 votes", f"open {days_open:.0f}d"]
            if days_until_end is not None and days_until_end > 0:
                status_parts.append(f"expiring in {days_until_end:.0f} days")
            lines.append(" • ".join(status_parts))

            if last_vote_time:
                lines.append(f"_Last vote {last_vote_time}_")

            # Actionable part - make it stand out!
            if missing_voters:
                lines.append("\n*MISSING VOTES:*")
                for voter in missing_voters:
                    lines.append(f"• {voter}")

        else:  # safe
            # Safe transaction
            nonce = item.get('nonce', 'Unknown')
            sig_count = item.get('sig_count', 0)
            days_open = item.get('days_open', 0)
            safe_label = item.get('safe_label', 'Safe')

            # Get missing signers
            missing_signers = item.get('missing_signers', [])

            # Get last signature time
            signed_members = item.get('signed_members', [])
            last_sig_time = None
            if signed_members:
                last_sig_hours = signed_members[-1]['time_hours']
                days = int(last_sig_hours // 24)
                hours = int(last_sig_hours % 24)
                if days > 0:
                    last_sig_time = f"{days}d {hours}h ago"
                else:
                    last_sig_time = f"{hours}h ago"

            # Platform badge + title
            lines.append(f"*{idx + 1}. 🔐 `Safe` • {safe_label} — Transaction #{nonce}*")
            lines.append(f"👉 <{item['url']}|View transaction>")

            # Status line
            status_parts = [f"{sig_count}/6 signatures", f"open {days_open:.0f}d"]
            lines.append(" • ".join(status_parts))

            if last_sig_time:
                lines.append(f"_Last signature {last_sig_time}_")

            # Actionable part - make it stand out!
            if missing_signers:
                lines.append("\n*MISSING SIGNATURES:*")
                for signer in missing_signers:
                    lines.append(f"• {signer}")

        # Add separator between items (but not after the last one)
        if idx < len(items) - 1:
            lines.append("\n───")

    # Footer
    lines.append("\n───\n")
    lines.append(f"📊 <https://dashboards.thegraph.foundation/grump/|View full dashboard>")

    # Add user mention if configured
    if config.SLACK_MENTION_USERS:
        user_ids = config.SLACK_MENTION_USERS.split(',')
        mentions = " ".join(f"<@{uid.strip()}>" for uid in user_ids if uid.strip())
        lines.append(f"\n_CC: {mentions}_")

    return "\n".join(lines)


def send_slack_notification(message: str) -> bool:
    """Send notification to Slack webhook"""
    webhook_url = config.SLACK_WEBHOOK_URL
    if not webhook_url:
        print(f"  ⚠️ SLACK_WEBHOOK_URL not set for environment '{config.ENVIRONMENT}', skipping notification")
        return False

    # Show which environment and webhook are being used
    webhook_preview = webhook_url[:50] + "..." if len(webhook_url) > 50 else webhook_url
    print(f"  📤 Sending to {config.ENVIRONMENT.upper()} webhook: {webhook_preview}")

    try:
        response = requests.post(
            webhook_url,
            json={
                "text": message,
                "username": "GOOSE",
                "icon_emoji": ":goose:"
            },
            timeout=10
        )
        response.raise_for_status()
        print(f"  ✅ Notification sent successfully to {config.ENVIRONMENT.upper()}")
        return True
    except Exception as e:
        print(f"  ❌ Failed to send Slack notification: {e}")
        return False


def check_and_alert():
    """
    Main function to check for active items and send alerts

    Only sends alert if there are active items requiring attention.
    This matches what users see on the frontend dashboard.
    """
    print("🔍 Checking for active proposals and transactions...")

    items = get_active_items_for_alerts()

    if not items:
        print("  ✅ No active items requiring attention")
        return True

    print(f"  ⚠️ Found {len(items)} active item(s) requiring attention")

    message = format_slack_message(items)
    print(f"\n📨 Alert message:\n{message}\n")

    return send_slack_notification(message)


if __name__ == "__main__":
    check_and_alert()
