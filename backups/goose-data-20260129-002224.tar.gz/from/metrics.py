"""
Metrics calculation for GOOSE
Computes time to quorum, individual response times, and participation rates
"""

import sqlite3
from datetime import datetime, timedelta
from config import DATABASE_PATH, QUORUM_THRESHOLD
from database import get_connection


def get_time_to_quorum_stats(platform=None, safe_address=None, days=None):
    """
    Calculate time to quorum statistics

    Args:
        platform: 'snapshot', 'safe', or None (both)
        safe_address: Filter by specific Safe (only for platform='safe')
        days: Filter by last N days

    Returns: dict with avg, median, min, max in hours
    """
    conn = get_connection()
    cursor = conn.cursor()

    # Build query based on platform
    if platform == 'snapshot':
        table = 'proposals'
        time_filter = ""
        if days:
            cutoff = int((datetime.now() - timedelta(days=days)).timestamp())
            time_filter = f"AND created_at >= {cutoff}"

        query = f"""
            SELECT
                (quorum_reached_at - created_at) as time_to_quorum
            FROM proposals
            WHERE quorum_reached_at IS NOT NULL
            {time_filter}
        """
    elif platform == 'safe':
        table = 'transactions'
        safe_filter = ""
        if safe_address:
            safe_filter = f"AND safe_address = '{safe_address}'"
        if days:
            cutoff = int((datetime.now() - timedelta(days=days)).timestamp())
            safe_filter += f" AND created_at >= {cutoff}"

        query = f"""
            SELECT
                (quorum_reached_at - created_at) as time_to_quorum
            FROM transactions
            WHERE quorum_reached_at IS NOT NULL
            {safe_filter}
        """
    else:
        # Both platforms
        time_filter_snapshot = ""
        time_filter_safe = ""
        if days:
            cutoff = int((datetime.now() - timedelta(days=days)).timestamp())
            time_filter_snapshot = f"AND created_at >= {cutoff}"
            time_filter_safe = f"AND created_at >= {cutoff}"

        query = f"""
            SELECT time_to_quorum FROM (
                SELECT (quorum_reached_at - created_at) as time_to_quorum
                FROM proposals
                WHERE quorum_reached_at IS NOT NULL
                {time_filter_snapshot}
                UNION ALL
                SELECT (quorum_reached_at - created_at) as time_to_quorum
                FROM transactions
                WHERE quorum_reached_at IS NOT NULL
                {time_filter_safe}
            )
        """

    cursor.execute(query)
    times = [row[0] for row in cursor.fetchall()]
    conn.close()

    if not times:
        return None

    # Convert to hours
    times_hours = [t / 3600 for t in times]
    times_hours.sort()

    stats = {
        'avg': sum(times_hours) / len(times_hours),
        'median': times_hours[len(times_hours) // 2],
        'min': min(times_hours),
        'max': max(times_hours),
        'count': len(times_hours)
    }

    return stats


def get_member_response_times():
    """
    Calculate average response time for each member
    Returns: list of dicts with member address, avg response time (overall and by platform), participation count
    """
    conn = get_connection()
    cursor = conn.cursor()

    # Get response times from Snapshot
    cursor.execute("""
        SELECT
            v.voter_address,
            AVG(v.voted_at - p.created_at) as avg_response_time,
            COUNT(*) as vote_count
        FROM votes v
        JOIN proposals p ON v.item_id = p.id
        WHERE v.platform = 'snapshot'
        GROUP BY v.voter_address
    """)
    snapshot_data = {row[0]: {'response_time': row[1], 'count': row[2]} for row in cursor.fetchall()}

    # Get response times from Safe
    cursor.execute("""
        SELECT
            v.voter_address,
            AVG(v.voted_at - t.created_at) as avg_response_time,
            COUNT(*) as vote_count
        FROM votes v
        JOIN transactions t ON v.item_id = t.id
        WHERE v.platform = 'safe'
        GROUP BY v.voter_address
    """)
    safe_data = {row[0]: {'response_time': row[1], 'count': row[2]} for row in cursor.fetchall()}

    # Get response times from Notion
    cursor.execute("""
        SELECT
            v.voter_address,
            AVG(v.voted_at - p.created_at) as avg_response_time,
            COUNT(*) as vote_count
        FROM votes v
        JOIN proposals p ON v.item_id = p.id
        WHERE v.platform = 'notion'
        GROUP BY v.voter_address
    """)
    notion_data = {row[0]: {'response_time': row[1], 'count': row[2]} for row in cursor.fetchall()}

    # Combine data from all three platforms
    all_members = set(list(snapshot_data.keys()) + list(safe_data.keys()) + list(notion_data.keys()))
    member_stats = []

    for member in all_members:
        snapshot_time = snapshot_data.get(member, {}).get('response_time', 0)
        snapshot_count = snapshot_data.get(member, {}).get('count', 0)
        safe_time = safe_data.get(member, {}).get('response_time', 0)
        safe_count = safe_data.get(member, {}).get('count', 0)
        notion_time = notion_data.get(member, {}).get('response_time', 0)
        notion_count = notion_data.get(member, {}).get('count', 0)

        total_time = (snapshot_time * snapshot_count + safe_time * safe_count + notion_time * notion_count)
        total_count = snapshot_count + safe_count + notion_count

        avg_time = total_time / total_count if total_count > 0 else 0

        member_stats.append({
            'address': member,
            'avg_response_time_hours': avg_time / 3600,
            'snapshot_response_time_hours': snapshot_time / 3600 if snapshot_time else None,
            'safe_response_time_hours': safe_time / 3600 if safe_time else None,
            'notion_response_time_hours': notion_time / 3600 if notion_time else None,
            'snapshot_votes': snapshot_count,
            'safe_votes': safe_count,
            'notion_votes': notion_count,
            'total_votes': total_count
        })

    conn.close()

    # Sort by average response time (fastest first)
    member_stats.sort(key=lambda x: x['avg_response_time_hours'])

    return member_stats


def get_participation_rate():
    """
    Calculate participation rate for each member
    Returns: list of dicts with member address, participation rate, and vote counts
    """
    conn = get_connection()
    cursor = conn.cursor()

    # Total number of Snapshot proposals
    cursor.execute("SELECT COUNT(*) FROM proposals WHERE platform = 'snapshot'")
    total_proposals = cursor.fetchone()[0]

    # Total number of transactions
    cursor.execute("SELECT COUNT(*) FROM transactions")
    total_transactions = cursor.fetchone()[0]

    # Total number of Notion proposals
    cursor.execute("SELECT COUNT(*) FROM proposals WHERE platform = 'notion'")
    total_notion = cursor.fetchone()[0]

    total_items = total_proposals + total_transactions + total_notion

    if total_items == 0:
        return []

    # Get vote counts per member
    cursor.execute("""
        SELECT
            voter_address,
            SUM(CASE WHEN platform = 'snapshot' THEN 1 ELSE 0 END) as snapshot_votes,
            SUM(CASE WHEN platform = 'safe' THEN 1 ELSE 0 END) as safe_votes,
            SUM(CASE WHEN platform = 'notion' THEN 1 ELSE 0 END) as notion_votes,
            COUNT(*) as total_votes
        FROM votes
        GROUP BY voter_address
    """)

    member_stats = []
    for row in cursor.fetchall():
        address = row[0]
        snapshot_votes = row[1]
        safe_votes = row[2]
        notion_votes = row[3]
        total_votes = row[4]

        participation_rate = (total_votes / total_items) * 100

        member_stats.append({
            'address': address,
            'participation_rate': participation_rate,
            'snapshot_votes': snapshot_votes,
            'safe_votes': safe_votes,
            'notion_votes': notion_votes,
            'total_votes': total_votes,
            'total_items': total_items
        })

    conn.close()

    # Sort by participation rate (highest first)
    member_stats.sort(key=lambda x: x['participation_rate'], reverse=True)

    return member_stats


def get_time_series_data(days=90, interval='week'):
    """
    Get time series data for time to quorum over a period
    Returns: list of dicts with timestamp and avg time to quorum
    """
    conn = get_connection()
    cursor = conn.cursor()

    cutoff = int((datetime.now() - timedelta(days=days)).timestamp())

    if interval == 'day':
        grouping = 86400  # 1 day in seconds
    elif interval == 'week':
        grouping = 604800  # 1 week in seconds
    else:  # month
        grouping = 2592000  # 30 days in seconds

    query = f"""
        SELECT
            (created_at / {grouping}) * {grouping} as period,
            AVG(quorum_reached_at - created_at) as avg_time_to_quorum,
            COUNT(*) as count
        FROM (
            SELECT created_at, quorum_reached_at
            FROM proposals
            WHERE quorum_reached_at IS NOT NULL AND created_at >= {cutoff}
            UNION ALL
            SELECT created_at, quorum_reached_at
            FROM transactions
            WHERE quorum_reached_at IS NOT NULL AND created_at >= {cutoff}
        )
        GROUP BY period
        ORDER BY period
    """

    cursor.execute(query)
    data = []
    for row in cursor.fetchall():
        data.append({
            'timestamp': row[0],
            'date': datetime.fromtimestamp(row[0]).strftime('%Y-%m-%d'),
            'avg_hours': row[1] / 3600,
            'count': row[2]
        })

    conn.close()
    return data


def get_summary_stats():
    """Get overall summary statistics with breakdown"""
    conn = get_connection()
    cursor = conn.cursor()

    # Snapshot proposals
    cursor.execute("SELECT COUNT(*) FROM proposals WHERE platform = 'snapshot'")
    total_proposals = cursor.fetchone()[0]

    cursor.execute("SELECT COUNT(*) FROM proposals WHERE platform = 'snapshot' AND quorum_reached_at IS NOT NULL")
    snapshot_with_quorum = cursor.fetchone()[0]

    # Safe transactions
    cursor.execute("SELECT COUNT(*) FROM transactions")
    total_transactions = cursor.fetchone()[0]

    cursor.execute("SELECT COUNT(*) FROM transactions WHERE quorum_reached_at IS NOT NULL")
    safe_with_quorum = cursor.fetchone()[0]

    # Notion proposals
    cursor.execute("SELECT COUNT(*) FROM proposals WHERE platform = 'notion'")
    total_notion = cursor.fetchone()[0]

    cursor.execute("SELECT COUNT(*) FROM proposals WHERE platform = 'notion' AND quorum_reached_at IS NOT NULL")
    notion_with_quorum = cursor.fetchone()[0]

    # Votes breakdown
    cursor.execute("SELECT COUNT(*) FROM votes WHERE platform = 'snapshot'")
    snapshot_votes = cursor.fetchone()[0]

    cursor.execute("SELECT COUNT(*) FROM votes WHERE platform = 'safe'")
    safe_votes = cursor.fetchone()[0]

    cursor.execute("SELECT COUNT(*) FROM votes WHERE platform = 'notion'")
    notion_votes = cursor.fetchone()[0]

    total_votes = snapshot_votes + safe_votes + notion_votes

    # Unique voters
    cursor.execute("SELECT COUNT(DISTINCT voter_address) FROM votes")
    unique_voters = cursor.fetchone()[0]

    conn.close()

    return {
        'total_proposals': total_proposals,
        'snapshot_proposals_with_quorum': snapshot_with_quorum,
        'total_transactions': total_transactions,
        'safe_transactions_with_quorum': safe_with_quorum,
        'total_notion': total_notion,
        'notion_with_quorum': notion_with_quorum,
        'total_items': total_proposals + total_transactions + total_notion,
        'total_votes': total_votes,
        'snapshot_votes': snapshot_votes,
        'safe_votes': safe_votes,
        'notion_votes': notion_votes,
        'unique_voters': unique_voters
    }


def get_safe_summary_stats():
    """Get summary stats for each Safe individually"""
    from config import SAFES

    stats_by_safe = []
    for safe in SAFES:
        conn = get_connection()
        cursor = conn.cursor()

        cursor.execute("""
            SELECT COUNT(*), AVG(quorum_reached_at - created_at)
            FROM transactions
            WHERE safe_address = ? AND quorum_reached_at IS NOT NULL
        """, (safe['address'],))

        result = cursor.fetchone()
        count = result[0]
        avg_time = result[1]
        conn.close()

        if count > 0:
            stats_by_safe.append({
                'label': safe['label'],
                'chain': safe['chain'],
                'address': safe['address'],
                'count': count,
                'avg_hours': (avg_time / 3600) if avg_time else 0
            })

    return stats_by_safe


def get_active_items():
    """
    Get all active items requiring attention
    Returns open Snapshot proposals and pending Safe transactions
    """
    from config import SAFES, QUORUM_THRESHOLD
    from database import get_member_display_name
    import time

    conn = get_connection()
    cursor = conn.cursor()
    now = int(time.time())

    active_items = []

    # Get open Snapshot proposals (not expired, not reached quorum)
    cursor.execute("""
        SELECT
            p.id,
            p.title,
            p.created_at,
            p.end_time,
            p.state,
            COUNT(DISTINCT v.voter_address) as vote_count
        FROM proposals p
        LEFT JOIN votes v ON p.id = v.item_id AND v.platform = 'snapshot'
        WHERE p.end_time > ?
          AND p.quorum_reached_at IS NULL
        GROUP BY p.id
        HAVING vote_count < ?
        ORDER BY p.created_at DESC
    """, (now, QUORUM_THRESHOLD))

    snapshot_rows = cursor.fetchall()

    # Get average time to quorum for Snapshot
    cursor.execute("""
        SELECT AVG(quorum_reached_at - created_at)
        FROM proposals
        WHERE quorum_reached_at IS NOT NULL
    """)
    avg_snapshot = cursor.fetchone()[0]
    avg_snapshot_hours = (avg_snapshot / 3600) if avg_snapshot else 6.0

    # Get current council members from CSV
    from council_lookup import load_council_members
    csv_members = load_council_members()
    csv_addresses = set(csv_members.keys())

    for row in snapshot_rows:
        proposal_id, title, created_at, end_at, state, vote_count = row
        hours_open = (now - created_at) / 3600
        days_open = hours_open / 24
        hours_until_end = (end_at - now) / 3600 if end_at else 0
        days_until_end = hours_until_end / 24

        # Determine if behind schedule
        is_behind = hours_open > avg_snapshot_hours
        behind_multiplier = hours_open / avg_snapshot_hours if is_behind and avg_snapshot_hours > 0 else 0

        # Get all votes for this proposal
        cursor.execute("""
            SELECT voter_address, voted_at
            FROM votes
            WHERE item_id = ? AND platform = 'snapshot'
            ORDER BY voted_at ASC
        """, (proposal_id,))
        votes = cursor.fetchall()
        voted_addresses = set(v[0].lower() for v in votes)

        # Build voted members list with timing
        voted_members = []
        for voter_addr, voted_at in votes:
            # Only include CSV members
            if voter_addr.lower() in csv_addresses:
                response_time_hours = (voted_at - created_at) / 3600
                voted_members.append({
                    'name': get_member_display_name(voter_addr),
                    'time_hours': response_time_hours
                })

        # Build missing voters list (only CSV members who haven't voted)
        missing_voters = []
        for csv_addr in csv_addresses:
            if csv_addr not in voted_addresses:
                missing_voters.append(get_member_display_name(csv_addr))

        active_items.append({
            'type': 'snapshot',
            'id': proposal_id,
            'title': title,
            'created_at': created_at,
            'end_at': end_at,
            'state': state,
            'vote_count': vote_count,
            'hours_open': hours_open,
            'days_open': days_open,
            'days_until_end': days_until_end,
            'avg_hours': avg_snapshot_hours,
            'is_behind': is_behind,
            'behind_multiplier': behind_multiplier,
            'voted_members': voted_members,
            'missing_voters': missing_voters,
            'platform': 'Snapshot',
            'url': f"https://snapshot.org/#/council.graphprotocol.eth/proposal/{proposal_id}"
        })

    # Get pending Safe transactions (not reached quorum, from last 30 days)
    cutoff = now - (30 * 86400)  # 30 days ago

    for safe in SAFES:
        cursor.execute("""
            SELECT
                t.id,
                t.nonce,
                t.created_at,
                t.safe_address,
                COUNT(DISTINCT v.voter_address) as sig_count
            FROM transactions t
            LEFT JOIN votes v ON t.id = v.item_id AND v.platform = 'safe'
            WHERE t.safe_address = ?
              AND t.created_at > ?
              AND t.quorum_reached_at IS NULL
            GROUP BY t.id
            HAVING sig_count < ?
            ORDER BY t.created_at DESC
        """, (safe['address'], cutoff, QUORUM_THRESHOLD))

        safe_rows = cursor.fetchall()

        # Get average time to quorum for this Safe
        cursor.execute("""
            SELECT AVG(quorum_reached_at - created_at)
            FROM transactions
            WHERE safe_address = ? AND quorum_reached_at IS NOT NULL
        """, (safe['address'],))
        avg_safe = cursor.fetchone()[0]
        avg_safe_hours = (avg_safe / 3600) if avg_safe else 12.0

        # Get current council members from CSV
        from council_lookup import load_council_members
        csv_members = load_council_members()
        csv_addresses = set(csv_members.keys())

        for row in safe_rows:
            tx_id, nonce, created_at, safe_address, sig_count = row
            hours_open = (now - created_at) / 3600
            days_open = hours_open / 24

            # Determine if behind schedule
            is_behind = hours_open > avg_safe_hours
            behind_multiplier = hours_open / avg_safe_hours if is_behind and avg_safe_hours > 0 else 0

            # Get all votes for this transaction
            cursor.execute("""
                SELECT voter_address, voted_at
                FROM votes
                WHERE item_id = ? AND platform = 'safe'
                ORDER BY voted_at ASC
            """, (tx_id,))
            votes = cursor.fetchall()
            voted_addresses = set(v[0].lower() for v in votes)

            # Build signed members list with timing
            signed_members = []
            for voter_addr, voted_at in votes:
                # Only include CSV members
                if voter_addr.lower() in csv_addresses:
                    response_time_hours = (voted_at - created_at) / 3600
                    signed_members.append({
                        'name': get_member_display_name(voter_addr),
                        'time_hours': response_time_hours
                    })

            # Build missing signers list (only CSV members who haven't signed)
            missing_signers = []
            for csv_addr in csv_addresses:
                if csv_addr not in voted_addresses:
                    missing_signers.append(get_member_display_name(csv_addr))

            safe_label = next(s['label'] for s in SAFES if s['address'] == safe_address)
            safe_chain = next(s['safe_chain'] for s in SAFES if s['address'] == safe_address)

            active_items.append({
                'type': 'safe',
                'id': tx_id,
                'nonce': nonce,
                'created_at': created_at,
                'safe_address': safe_address,
                'safe_label': safe_label,
                'sig_count': sig_count,
                'hours_open': hours_open,
                'days_open': days_open,
                'avg_hours': avg_safe_hours,
                'is_behind': is_behind,
                'behind_multiplier': behind_multiplier,
                'signed_members': signed_members,
                'missing_signers': missing_signers,
                'platform': safe_label,
                'url': f"https://app.safe.global/transactions/queue?safe={safe_chain}:{safe_address}"
            })

    # Get active Notion proposals (not reached quorum)
    cursor.execute("""
        SELECT
            p.id,
            p.title,
            p.created_at,
            p.end_time,
            p.state,
            COUNT(DISTINCT v.voter_address) as vote_count
        FROM proposals p
        LEFT JOIN votes v ON p.id = v.item_id AND v.platform = 'notion'
        WHERE p.platform = 'notion'
          AND p.quorum_reached_at IS NULL
        GROUP BY p.id
        HAVING vote_count < ?
        ORDER BY p.created_at DESC
    """, (QUORUM_THRESHOLD,))

    notion_rows = cursor.fetchall()

    # Get average time to quorum across ALL platforms (Snapshot + Safe) for baseline
    # This gives a meaningful comparison to overall governance speed
    cursor.execute("""
        SELECT AVG(p.quorum_reached_at - p.created_at)
        FROM proposals p
        WHERE p.quorum_reached_at IS NOT NULL
    """)
    avg_all = cursor.fetchone()[0]
    # Convert to hours, default to 24 hours if no data
    avg_all_hours = (avg_all / 3600) if avg_all else 24.0

    for row in notion_rows:
        proposal_id, title, created_at, deadline, state, vote_count = row
        hours_open = (now - created_at) / 3600
        days_open = hours_open / 24

        # Calculate deadline info
        if deadline:
            hours_until_deadline = (deadline - now) / 3600
            days_until_deadline = hours_until_deadline / 24
            # If there's a deadline, use that to determine if behind
            is_behind = hours_until_deadline < 0  # Past deadline
            behind_multiplier = days_open / (days_until_deadline + days_open) if is_behind else 0
        else:
            days_until_deadline = None
            # No deadline: compare against cross-platform average
            # Flag as behind if 2x the average time to quorum across all platforms
            is_behind = hours_open > (avg_all_hours * 2)
            behind_multiplier = hours_open / avg_all_hours if is_behind and avg_all_hours > 0 else 0

        # Get all votes for this proposal
        cursor.execute("""
            SELECT voter_address, voted_at
            FROM votes
            WHERE item_id = ? AND platform = 'notion'
            ORDER BY voted_at ASC
        """, (proposal_id,))
        votes = cursor.fetchall()
        voted_addresses = set(v[0].lower() for v in votes)

        # Build voted members list
        voted_members = []
        for voter_addr, voted_at in votes:
            if voter_addr.lower() in csv_addresses:
                response_time_hours = (voted_at - created_at) / 3600
                voted_members.append({
                    'name': get_member_display_name(voter_addr),
                    'time_hours': response_time_hours
                })

        # Build missing voters
        missing_voters = []
        for csv_addr in csv_addresses:
            if csv_addr not in voted_addresses:
                missing_voters.append(get_member_display_name(csv_addr))

        active_items.append({
            'type': 'notion',
            'id': proposal_id,
            'title': title,
            'created_at': created_at,
            'end_at': deadline,
            'state': state,
            'vote_count': vote_count,
            'hours_open': hours_open,
            'days_open': days_open,
            'days_until_end': days_until_deadline,
            'avg_hours': avg_all_hours,
            'is_behind': is_behind,
            'behind_multiplier': behind_multiplier,
            'voted_members': voted_members,
            'missing_voters': missing_voters,
            'platform': 'Notion',
            'url': f"https://notion.so/{proposal_id.replace('-', '')}"
        })

    conn.close()

    # Sort active items by priority:
    # 1. Deadline first (earliest deadline = most urgent)
    # 2. Then by how long open (oldest = most waiting)
    def sort_key(item):
        # Primary: deadline (None should sort LAST - items with deadlines are more urgent)
        deadline = item.get('end_at')  # This is end_time from DB, can be None
        if deadline is None:
            # No deadline - put at the end with a large timestamp
            deadline_priority = float('inf')
        else:
            # Has deadline - lower timestamp = more urgent
            deadline_priority = deadline

        # Secondary: created_at (older = more waiting = higher priority)
        created_at = item.get('created_at', 0)

        return (deadline_priority, created_at)

    active_items.sort(key=sort_key)

    return active_items


if __name__ == "__main__":
    # Test metrics
    print("=== Time to Quorum Stats ===")
    stats = get_time_to_quorum_stats()
    if stats:
        print(f"Average: {stats['avg']:.2f} hours")
        print(f"Median: {stats['median']:.2f} hours")
        print(f"Min: {stats['min']:.2f} hours")
        print(f"Max: {stats['max']:.2f} hours")

    print("\n=== Member Response Times ===")
    members = get_member_response_times()
    for m in members[:5]:
        print(f"{m['address'][:10]}... - {m['avg_response_time_hours']:.2f} hours")

    print("\n=== Participation Rates ===")
    participation = get_participation_rate()
    for p in participation[:5]:
        print(f"{p['address'][:10]}... - {p['participation_rate']:.1f}%")
