"""
Incremental data updates for GOOSE
Only fetches new/changed data since last sync
"""

import time
from database import (
    get_last_sync, update_last_sync, get_max_created_timestamp,
    save_proposal, save_transaction, save_vote, save_member
)
from config import SNAPSHOT_SPACE, QUORUM_THRESHOLD, SAFES, NOTION_CONFIG


def update_snapshot_incremental():
    """
    Fetch only new Snapshot proposals since last sync.
    Returns True if new data was found, False otherwise.
    """
    import requests
    from collectors.snapshot import fetch_votes_for_proposal, calculate_quorum_time

    last_sync, _ = get_last_sync('snapshot')
    current_max = get_max_created_timestamp('snapshot')

    # Use the more recent of: last_sync_time OR current_max_in_db
    # This handles the case where we have old data but sync_state is reset
    since_timestamp = max(last_sync, current_max)

    print(f"📊 Snapshot incremental update (since {since_timestamp or 'beginning'})...")

    # Fetch proposals from Snapshot API with filtering
    query = """
    query Proposals($space: String!, $first: Int!) {
      proposals(
        first: $first,
        where: { space: $space },
        orderBy: "created",
        orderDirection: desc
      ) {
        id
        title
        created
        start
        end
        state
        author
        votes
      }
    }
    """

    response = requests.post(
        "https://hub.snapshot.org/graphql",
        json={"query": query, "variables": {"space": SNAPSHOT_SPACE, "first": 100}}
    )
    response.raise_for_status()
    proposals = response.json().get("data", {}).get("proposals", [])

    # Filter to only new proposals
    new_proposals = [p for p in proposals if p['created'] > since_timestamp]

    if not new_proposals:
        print("  ✅ No new Snapshot proposals")
        return False

    print(f"  Found {len(new_proposals)} new proposals")

    new_data_found = False
    for i, proposal in enumerate(new_proposals):
        print(f"  Processing {i+1}/{len(new_proposals)}: {proposal['title'][:50]}...")

        # Fetch votes
        votes = fetch_votes_for_proposal(proposal['id'])

        # Calculate quorum time
        quorum_time = calculate_quorum_time(votes)

        # Save proposal
        proposal_data = {
            'id': proposal['id'],
            'title': proposal['title'],
            'created_at': proposal['created'],
            'start_time': proposal['start'],
            'end_time': proposal['end'],
            'state': proposal['state'],
            'quorum_reached_at': quorum_time
        }
        save_proposal(proposal_data)

        # Save author and votes
        save_member(proposal['author'])
        for vote in votes:
            save_vote(
                item_id=proposal['id'],
                voter_address=vote['voter'],
                voted_at=vote['created'],
                platform='snapshot'
            )
            save_member(vote['voter'])

        # Delay for rate limiting
        time.sleep(1.2)
        new_data_found = True

    # Update sync state with the latest proposal timestamp
    if new_proposals:
        latest_timestamp = max(p['created'] for p in new_proposals)
        import time as time_module
        update_last_sync('snapshot', int(time_module.time()), len(new_proposals))

    print(f"  ✅ Snapshot incremental update complete ({len(new_proposals)} new)")
    return new_data_found


def update_safe_incremental():
    """
    Fetch Safe transactions and update signatures.
    Processes ALL transactions to catch new signatures on existing transactions.
    Returns True if new data was found, False otherwise.
    """
    import requests
    from collectors.safe import calculate_quorum_time_safe, parse_timestamp

    last_sync, _ = get_last_sync('safe')
    current_max = get_max_created_timestamp('safe')

    since_timestamp = max(last_sync, current_max)
    print(f"📊 Safe incremental update (since {since_timestamp or 'beginning'})...")

    new_data_found = False
    total_new = 0
    total_updated = 0

    for safe in SAFES:
        label = safe.get('label', safe['chain'])
        print(f"  Checking {label}...")

        # Fetch transactions from Safe API
        url = f"{safe['api_url']}/safes/{safe['address']}/multisig-transactions/"
        params = {"limit": 100, "ordering": "-nonce"}

        try:
            response = requests.get(url, params=params, timeout=30)
            response.raise_for_status()
            transactions = response.json().get("results", [])
        except Exception as e:
            print(f"  ⚠️ Error fetching from {label}: {e}")
            continue

        # Process ALL transactions (not just new ones) to catch new signatures
        # on existing transactions
        new_transactions = []
        existing_transactions_to_update = []

        for tx in transactions:
            created_at = parse_timestamp(tx.get('submissionDate'))
            safe_tx_hash = tx.get('safeTxHash')
            confirmations = tx.get('confirmations', [])

            # Check if this transaction exists in database
            conn = get_connection()
            cursor = conn.cursor()
            cursor.execute("SELECT COUNT(*) FROM votes WHERE item_id = ? AND platform = 'safe'", (safe_tx_hash,))
            current_sig_count = cursor.fetchone()[0]
            conn.close()

            api_sig_count = len(confirmations)

            if created_at and created_at > since_timestamp:
                # New transaction
                new_transactions.append((tx, created_at))
            elif api_sig_count > current_sig_count:
                # Existing transaction with new signatures
                existing_transactions_to_update.append((tx, created_at))

        if new_transactions:
            print(f"    Found {len(new_transactions)} new transactions from {label}")
            total_new += len(new_transactions)

        if existing_transactions_to_update:
            print(f"    Found {len(existing_transactions_to_update)} transactions with new signatures")
            total_updated += len(existing_transactions_to_update)

        # Process new transactions
        for tx, created_at in new_transactions:
            safe_tx_hash = tx.get('safeTxHash')
            nonce = tx.get('nonce')
            submission_date = tx.get('submissionDate')
            execution_date = tx.get('executionDate')
            confirmations = tx.get('confirmations', [])

            # Calculate quorum time
            quorum_time = calculate_quorum_time_safe(confirmations, submission_date)

            # Save transaction
            tx_data = {
                'id': safe_tx_hash,
                'safe_tx_hash': safe_tx_hash,
                'created_at': created_at,
                'executed_at': parse_timestamp(execution_date),
                'quorum_reached_at': quorum_time,
                'nonce': nonce,
                'safe_address': safe['address']
            }
            save_transaction(tx_data)

            # Save confirmations as votes
            for confirmation in confirmations:
                owner = confirmation.get('owner')
                submission = confirmation.get('submissionDate', submission_date)

                save_vote(
                    item_id=safe_tx_hash,
                    voter_address=owner,
                    voted_at=parse_timestamp(submission),
                    platform='safe'
                )
                save_member(owner)

            new_data_found = True

        # Process existing transactions with new signatures
        for tx, created_at in existing_transactions_to_update:
            safe_tx_hash = tx.get('safeTxHash')
            submission_date = tx.get('submissionDate')
            confirmations = tx.get('confirmations', [])

            # Calculate quorum time (may have changed)
            quorum_time = calculate_quorum_time_safe(confirmations, submission_date)

            # Update transaction (quorum_reached_at may have changed)
            tx_data = {
                'id': safe_tx_hash,
                'safe_tx_hash': safe_tx_hash,
                'created_at': created_at,
                'executed_at': parse_timestamp(tx.get('executionDate')),
                'quorum_reached_at': quorum_time,
                'nonce': tx.get('nonce'),
                'safe_address': safe['address']
            }
            save_transaction(tx_data)

            # Save new confirmations as votes (INSERT OR IGNORE handles duplicates)
            for confirmation in confirmations:
                owner = confirmation.get('owner')
                submission = confirmation.get('submissionDate', submission_date)

                save_vote(
                    item_id=safe_tx_hash,
                    voter_address=owner,
                    voted_at=parse_timestamp(submission),
                    platform='safe'
                )
                save_member(owner)

            new_data_found = True

        if not new_transactions and not existing_transactions_to_update:
            print(f"    No new transactions or signatures from {label}")

    # Update sync state
    if new_data_found:
        import time as time_module
        update_last_sync('safe', int(time_module.time()), total_new + total_updated)

    print(f"  ✅ Safe incremental update complete ({total_new} new, {total_updated} updated)")
    return new_data_found


def update_notion_incremental():
    """
    Fetch Notion proposals since last sync.
    Returns True if new data was found, False otherwise.
    """
    # Check if Notion is configured
    if not NOTION_CONFIG.get('api_token') or not NOTION_CONFIG.get('database_id'):
        print("⊘ Notion not configured - skipping")
        return False

    from collectors.notion import collect_notion_data

    print("📊 Notion incremental update...")
    try:
        # Run the full Notion collection (it handles filtering internally)
        # The Notion API doesn't support timestamp-based filtering easily,
        # so we fetch all and filter by last edited time
        collect_notion_data()

        # Check if we have any new Notion proposals
        from database import get_connection
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("""
            SELECT COUNT(*) FROM proposals WHERE platform = 'notion'
        """)
        count = cursor.fetchone()[0]
        conn.close()

        print(f"  ✅ Notion incremental update complete ({count} total proposals)")
        return count > 0
    except Exception as e:
        print(f"  ⚠️ Notion update failed: {e}")
        return False


def check_and_update_incremental():
    """
    Check for new data from all platforms and update if found.
    Returns True if any new data was found, False otherwise.
    """
    print("\n" + "=" * 60)
    print("🔄 Checking for new governance data...")
    print("=" * 60)

    snapshot_new = update_snapshot_incremental()
    safe_new = update_safe_incremental()
    notion_new = update_notion_incremental()

    has_new_data = snapshot_new or safe_new or notion_new

    if not has_new_data:
        print("\n✅ No new data found - skipping HTML regeneration")
    else:
        print("\n📈 New data found - HTML will be regenerated")

    return has_new_data


if __name__ == "__main__":
    from database import init_db
    init_db()
    check_and_update_incremental()
