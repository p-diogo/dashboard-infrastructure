#!/usr/bin/env python3
"""
GOOSE Monitor - Check for governance items requiring attention
Can be run standalone or imported as module
"""

from alerts import check_and_alert

if __name__ == "__main__":
    success = check_and_alert()
    exit(0 if success else 1)
