"""
Generate static HTML dashboard for THE GRUMPY GOOSE
This script generates a self-contained HTML file with all data embedded
"""

import os
import shutil
from typing import Dict
from datetime import datetime
from config import SAFES, DATABASE_PATH, OUTPUT_DIR
from metrics import (
    get_time_to_quorum_stats,
    get_member_response_times,
    get_participation_rate,
    get_summary_stats,
    get_active_items
)
from database import get_member_display_name


def format_hours(hours):
    """Format hours to readable format"""
    if hours < 1:
        return f"{int(round(hours * 60))} min"
    elif hours < 24:
        return f"{hours:.1f}h"
    else:
        days = hours / 24
        return f"{days:.1f} days"


def get_vote_color_info(vote_count: int, threshold: int = 6) -> dict:
    """
    Returns color class and label based on vote proximity to threshold.

    Args:
        vote_count: Current number of votes/signatures
        threshold: Quorum threshold (default: 6)

    Returns:
        Dict with color_class, color_hex, and label
    """
    if vote_count <= 2:
        return {
            'color_class': 'red',
            'color_hex': '#ef4444',
            'label': 'Critical'
        }
    elif vote_count <= 4:
        return {
            'color_class': 'yellow',
            'color_hex': '#f59e0b',
            'label': 'In Progress'
        }
    else:
        return {
            'color_class': 'green',
            'color_hex': '#10b981',
            'label': 'Almost There'
        }


def read_css():
    """Read the CSS file"""
    css_path = os.path.join('static', 'style.css')
    with open(css_path, 'r') as f:
        return f.read()


def format_quorum_stats(stats):
    """Helper to format quorum statistics as HTML"""
    if not stats:
        return '<div class="metric-row"><span>No data available</span></div>'

    return f"""
        <div class="metric-stats">
            <div class="metric-row">
                <span>Average:</span>
                <span class="value">{format_hours(stats['avg'])}</span>
            </div>
            <div class="metric-row">
                <span>Median:</span>
                <span class="value">{format_hours(stats['median'])}</span>
            </div>
            <div class="metric-row">
                <span>Min:</span>
                <span class="value">{format_hours(stats['min'])}</span>
            </div>
            <div class="metric-row">
                <span>Max:</span>
                <span class="value">{format_hours(stats['max'])}</span>
            </div>
            <div class="metric-row">
                <span>Total:</span>
                <span class="value">{stats['count']} items</span>
            </div>
        </div>
    """


def generate_html():
    """Generate static HTML with embedded data"""

    # Fetch all data
    print("Fetching data from database...")
    summary = get_summary_stats()
    quorum_all = get_time_to_quorum_stats()
    quorum_snapshot = get_time_to_quorum_stats(platform='snapshot')
    active_items = get_active_items()

    # Fetch per-Safe stats
    safe_stats = []
    for safe in SAFES:
        stats = get_time_to_quorum_stats(platform='safe', safe_address=safe['address'])
        safe_stats.append({
            'label': safe['label'],
            'chain': safe['chain'],
            'stats': stats
        })

    participation = get_participation_rate()
    response_times = get_member_response_times()

    # Load CSV members to filter leaderboard
    from council_lookup import load_council_members
    csv_members = load_council_members()
    csv_addresses = set(addr.lower() for addr in csv_members.keys())

    # Create response time lookup
    response_dict = {member['address'].lower(): member for member in response_times}

    # Filter participation to only CSV members
    participation_filtered = [
        m for m in participation
        if m['address'].lower() in csv_addresses
    ]

    # Combine leaderboard data (top 10 by participation from CSV members only)
    leaderboard = []
    for member in participation_filtered[:10]:
        address = member['address']
        response_data = response_dict.get(address.lower(), {})

        leaderboard.append({
            'address': address,
            'display_name': get_member_display_name(address),
            'participation_rate': member['participation_rate'],
            'snapshot_votes': member['snapshot_votes'],
            'safe_votes': member['safe_votes'],
            'notion_votes': member['notion_votes'],
            'total_votes': member['total_votes'],
            'avg_response_time_hours': response_data.get('avg_response_time_hours', 0),
            'snapshot_response_time_hours': response_data.get('snapshot_response_time_hours'),
            'safe_response_time_hours': response_data.get('safe_response_time_hours'),
            'notion_response_time_hours': response_data.get('notion_response_time_hours')
        })

    # Read CSS
    css_content = read_css()
    
    # Generate timestamp
    timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S UTC')
    
    # Generate HTML
    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GOOSE 🪿 - Governance Oversight & Operational Speed Evaluator</title>
    <link rel="icon" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><text y='.9em' font-size='90'>🪿</text></svg>">
    <style>
{css_content}
    </style>
    <link rel="stylesheet" href="/variants.css">
</head>
<body>
    <div class="container">
        <header>
            <h1>🪿 GOOSE</h1>
            <p class="subtitle">Governance Oversight & Operational Speed Evaluator</p>

            <!-- Update Controls -->
            <div class="update-controls" style="margin-top: 15px; display: flex; align-items: center; gap: 15px; flex-wrap: wrap;">
                <button id="update-btn" onclick="triggerUpdate()" style="
                    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                    color: white;
                    border: none;
                    padding: 10px 20px;
                    border-radius: 8px;
                    font-size: 14px;
                    font-weight: 600;
                    cursor: pointer;
                    transition: transform 0.2s, box-shadow 0.2s;
                    box-shadow: 0 4px 15px rgba(102, 126, 234, 0.3);
                " onmouseover="this.style.transform='translateY(-2px)'; this.style.boxShadow='0 6px 20px rgba(102, 126, 234, 0.4)'" onmouseout="this.style.transform='translateY(0)'; this.style.boxShadow='0 4px 15px rgba(102, 126, 234, 0.3)'">
                    🔄 Update Data
                </button>
                <span id="update-status" style="font-size: 0.85em; opacity: 0.8;"></span>
                <span class="subtitle" style="font-size: 0.85em; opacity: 0.7;">
                    Last updated: {timestamp}
                </span>
            </div>
        </header>

        <section class="summary-cards">
            <div class="card">
                <h3>Snapshot Proposals</h3>
                <div class="stat">{summary['total_proposals']}</div>
                <div class="stat-detail">{summary['snapshot_proposals_with_quorum']} reached quorum</div>
            </div>
            <div class="card">
                <h3>Safe Transactions</h3>
                <div class="stat">{summary['total_transactions']}</div>
                <div class="stat-detail">{summary['safe_transactions_with_quorum']} reached quorum</div>
            </div>
            <div class="card">
                <h3>Notion Proposals</h3>
                <div class="stat">{summary['total_notion']}</div>
                <div class="stat-detail">{summary['notion_with_quorum']} reached quorum</div>
            </div>
            <div class="card">
                <h3>Total Governance Items</h3>
                <div class="stat">{summary['total_items']}</div>
                <div class="stat-detail">All platforms combined</div>
            </div>
            <div class="card">
                <h3>Total Votes & Signatures</h3>
                <div class="stat">{summary['total_votes']}</div>
                <div class="stat-detail">{summary['snapshot_votes']} votes • {summary['safe_votes']} signed • {summary['notion_votes']} notion</div>
            </div>
        </section>

        <section class="active-items-section">
            <h2>⚠️  Active Items Requiring Action</h2>
"""

    # Group active items by type
    safe_items = [item for item in active_items if item['type'] == 'safe']
    snapshot_items = [item for item in active_items if item['type'] == 'snapshot']
    notion_items = [item for item in active_items if item['type'] == 'notion']

    # Helper function to render a single active item (Variant 1: Circular Donut)
    def render_active_item(item):
        """
        Render active item card with circular donut chart progress indicator.

        Variant 1: Large SVG donut chart with vote count in center.
        """
        # Get color info
        vote_count = item.get('vote_count') or item.get('sig_count', 0)
        color_info = get_vote_color_info(vote_count)

        # Calculate donut progress (circumference = 2 * pi * r, r=40 → ~251)
        percentage = min(vote_count / 6, 1.0)
        circumference = 251.3
        offset = circumference * (1 - percentage)

        # Common header setup
        if item['type'] == 'snapshot':
            type_label = "📸 SNAPSHOT"
            title = item['title']
            count_label = f"{vote_count}/6 votes"
        elif item['type'] == 'notion':
            type_label = "📝 NOTION"
            title = item['title']
            count_label = f"{vote_count}/6 votes"
        else:  # safe
            type_label = "🔐 SAFE"
            title = f"Transaction #{item['nonce']}"
            count_label = f"{vote_count}/6 sigs"

        # Build lists
        if item['type'] in ['snapshot', 'notion']:
            voted_list = item.get('voted_members', [])
            missing_list = item.get('missing_voters', [])
            voted_label = "ALREADY VOTED"
            missing_label = "STILL NEED TO VOTE"
        else:  # safe
            voted_list = item.get('signed_members', [])
            missing_list = item.get('missing_signers', [])
            voted_label = "ALREADY SIGNED"
            missing_label = "STILL NEED TO SIGN"

        # Build voted HTML
        if voted_list:
            medals = ["🥇", "🥈", "🥉"]
            voted_items = " ".join(
                f'<span class="signed-item">{medals[i] if i < 3 else ""} {m["name"]}</span>'
                for i, m in enumerate(voted_list)
            )
            voted_html = f'<div class="signed-list">{voted_items}</div>'
        else:
            voted_html = '<div class="signed-list">No votes yet</div>'

        # Build missing HTML
        if missing_list:
            missing_items = " ".join(f'<span class="missing-item">{v}</span>' for v in missing_list)
            missing_html = f'<div class="missing-list">{missing_items}</div>'
        else:
            missing_html = '<div class="signed-list">✅ All votes received</div>'

        # Time display
        hours_open = item.get('hours_open', 0)
        days = int(hours_open // 24)
        hours = int(hours_open % 24)
        if days > 0:
            time_display = f"{days}d {hours}h"
        else:
            time_display = f"{hours}h"

        return f"""
            <div class="active-item variant-donut">
                <div class="active-item-header">
                    <div class="donut-container">
                        <svg class="donut-svg" viewBox="0 0 100 100">
                            <circle class="donut-circle-bg" cx="50" cy="50" r="40"/>
                            <circle class="donut-circle-fill donut-fill-{color_info['color_class']}"
                                    cx="50" cy="50" r="40"
                                    stroke-dasharray="{circumference}"
                                    stroke-dashoffset="{offset}"/>
                        </svg>
                        <div class="donut-text">{vote_count}</div>
                        <div class="donut-subtext">/ 6</div>
                    </div>
                    <div style="flex: 1;">
                        <div class="active-item-type">{type_label}</div>
                        <div class="active-item-title">{title}</div>
                    </div>
                </div>
                <div class="active-item-status">
                    <strong style="color: {color_info['color_hex']};">{color_info['label']}</strong> • Open for {time_display}
                </div>
                <div class="active-item-signed">
                    ✅ {voted_label}:
                    {voted_html}
                </div>
                <div class="active-item-missing">
                    🚫 {missing_label}:
                    {missing_html}
                </div>
                <div class="active-item-link">
                    🔗 <a href="{item['url']}" target="_blank">View Details</a>
                </div>
            </div>
"""

    # Helper function to render a subsection
    def render_subsection(title, icon, items):
        if not items:
            return ""

        items_html = "".join(render_active_item(item) for item in items)
        return f"""
            <div class="active-items-subsection">
                <h3>
                    <span class="subsection-icon">{icon}</span>
                    <span>{title}</span>
                    <span class="subsection-count">{len(items)}</span>
                </h3>
                <div class="active-items-grid">
                    {items_html}
                </div>
            </div>
"""

    # Add active items by subsection
    if active_items:
        # Safe Transactions subsection
        html += render_subsection("Transaction Signing", "🔐", safe_items)

        # Snapshot Proposals subsection
        html += render_subsection("Snapshot Proposals", "📸", snapshot_items)

        # Notion Async Voting subsection
        html += render_subsection("Asynchronous Voting", "📝", notion_items)
    else:
        html += """
            <div class="active-item empty">
                ✅ All caught up! No active proposals or transactions requiring attention.
            </div>
"""

    html += """
        </section>

        <section class="metrics-section">
            <h2>⏱️ Time to Quorum (6 of 10 signatures)</h2>

            <div class="metrics-grid">
                <div class="metric-card">
                    <h4>All Platforms</h4>
                    <div class="metric-stats">
"""
    
    # Add quorum stats for all platforms
    if quorum_all:
        html += f"""
                        <div class="metric-row">
                            <span>Average:</span>
                            <span class="value">{format_hours(quorum_all['avg'])}</span>
                        </div>
                        <div class="metric-row">
                            <span>Median:</span>
                            <span class="value">{format_hours(quorum_all['median'])}</span>
                        </div>
                        <div class="metric-row">
                            <span>Min:</span>
                            <span class="value">{format_hours(quorum_all['min'])}</span>
                        </div>
                        <div class="metric-row">
                            <span>Max:</span>
                            <span class="value">{format_hours(quorum_all['max'])}</span>
                        </div>
"""
    else:
        html += """
                        <div class="metric-row">
                            <span>No data available</span>
                        </div>
"""
    
    html += """
                    </div>
                </div>

                <div class="metric-card">
                    <h4>Snapshot</h4>
                    <div class="metric-stats">
"""
    
    # Add quorum stats for Snapshot
    if quorum_snapshot:
        html += f"""
                        <div class="metric-row">
                            <span>Average:</span>
                            <span class="value">{format_hours(quorum_snapshot['avg'])}</span>
                        </div>
                        <div class="metric-row">
                            <span>Median:</span>
                            <span class="value">{format_hours(quorum_snapshot['median'])}</span>
                        </div>
                        <div class="metric-row">
                            <span>Min:</span>
                            <span class="value">{format_hours(quorum_snapshot['min'])}</span>
                        </div>
                        <div class="metric-row">
                            <span>Max:</span>
                            <span class="value">{format_hours(quorum_snapshot['max'])}</span>
                        </div>
"""
    else:
        html += """
                        <div class="metric-row">
                            <span>No data available</span>
                        </div>
"""
    
    html += """
                    </div>
                </div>
"""

    # Add metric card for each Safe
    for safe_stat in safe_stats:
        html += f"""
                <div class="metric-card">
                    <h4>{safe_stat['label']}</h4>
                    {format_quorum_stats(safe_stat['stats'])}
                </div>
"""

    html += """
            </div>

        </section>

        <section class="leaderboard-section">
            <h2>🏆 Leaderboard</h2>
            <div class="leaderboard">
"""
    
    # Add leaderboard items
    for index, member in enumerate(leaderboard):
        # Build response time breakdown
        response_breakdown = ''
        if member['snapshot_response_time_hours'] is not None and member['safe_response_time_hours'] is not None and member['notion_response_time_hours'] is not None:
            response_breakdown = f'<div class="stat-breakdown">Snapshot: {format_hours(member["snapshot_response_time_hours"])} | Safe: {format_hours(member["safe_response_time_hours"])} | Notion: {format_hours(member["notion_response_time_hours"])}</div>'
        elif member['snapshot_response_time_hours'] is not None and member['safe_response_time_hours'] is not None:
            response_breakdown = f'<div class="stat-breakdown">Snapshot: {format_hours(member["snapshot_response_time_hours"])} | Safe: {format_hours(member["safe_response_time_hours"])}</div>'
        elif member['snapshot_response_time_hours'] is not None and member['notion_response_time_hours'] is not None:
            response_breakdown = f'<div class="stat-breakdown">Snapshot: {format_hours(member["snapshot_response_time_hours"])} | Notion: {format_hours(member["notion_response_time_hours"])}</div>'
        elif member['safe_response_time_hours'] is not None and member['notion_response_time_hours'] is not None:
            response_breakdown = f'<div class="stat-breakdown">Safe: {format_hours(member["safe_response_time_hours"])} | Notion: {format_hours(member["notion_response_time_hours"])}</div>'
        elif member['snapshot_response_time_hours'] is not None:
            response_breakdown = f'<div class="stat-breakdown">Snapshot: {format_hours(member["snapshot_response_time_hours"])}</div>'
        elif member['safe_response_time_hours'] is not None:
            response_breakdown = f'<div class="stat-breakdown">Safe: {format_hours(member["safe_response_time_hours"])}</div>'
        elif member['notion_response_time_hours'] is not None:
            response_breakdown = f'<div class="stat-breakdown">Notion: {format_hours(member["notion_response_time_hours"])}</div>'

        top_three_class = 'top-three' if index < 3 else ''

        html += f"""
                <div class="leaderboard-item {top_three_class}">
                    <div class="rank">{index + 1}</div>
                    <div class="member-info">
                        <div class="address">{member['display_name']}</div>
                        <div class="details">
                            {member['snapshot_votes']} votes • {member['safe_votes']} signed • {member['notion_votes']} notion • {member['total_votes']} total
                        </div>
                    </div>
                    <div class="stats">
                        <div class="stat-item">
                            <div class="stat-label">Participation</div>
                            <div class="stat-value">{member['participation_rate']:.1f}%</div>
                        </div>
                        <div class="stat-item">
                            <div class="stat-label">Avg Response</div>
                            <div class="stat-value">{format_hours(member['avg_response_time_hours'])}</div>
                            {response_breakdown}
                        </div>
                    </div>
                </div>
"""
    
    html += """
            </div>
        </section>
    </div>

    <script>
        let updateInProgress = false;

        async function triggerUpdate() {
            if (updateInProgress) {
                alert('Update already in progress!');
                return;
            }

            const btn = document.getElementById('update-btn');
            const status = document.getElementById('update-status');

            updateInProgress = true;
            btn.disabled = true;
            btn.textContent = '⏳ Updating...';
            status.textContent = 'Fetching data from APIs...';

            try {
                const response = await fetch('/api/update', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    }
                });

                if (response.ok) {
                    status.textContent = 'Update started! This may take 1-2 minutes...';
                    pollForCompletion();
                } else {
                    const data = await response.json();
                    status.textContent = 'Error: ' + (data.error || 'Unknown error');
                    updateInProgress = false;
                    btn.disabled = false;
                    btn.textContent = '🔄 Update Data';
                }
            } catch (error) {
                status.textContent = 'Error: Could not connect to server';
                updateInProgress = false;
                btn.disabled = false;
                btn.textContent = '🔄 Update Data';
            }
        }

        function pollForCompletion() {
            const status = document.getElementById('update-status');
            const btn = document.getElementById('update-btn');

            const checkStatus = async () => {
                try {
                    const response = await fetch('/api/status');
                    const data = await response.json();

                    if (!data.update_running) {
                        // Update complete
                        updateInProgress = false;
                        btn.disabled = false;
                        btn.textContent = '🔄 Update Data';

                        if (data.last_result === 'success') {
                            status.textContent = '✅ Update complete! Reloading...';
                            setTimeout(() => location.reload(), 1500);
                        } else {
                            status.textContent = '❌ Update failed: ' + data.last_result;
                        }
                    } else {
                        // Still running
                        status.textContent = '⏳ Updating... (started ' + timeSince(data.last_started) + ' ago)';
                        setTimeout(checkStatus, 3000);
                    }
                } catch (error) {
                    status.textContent = 'Error checking status';
                    setTimeout(checkStatus, 5000);
                }
            };

            setTimeout(checkStatus, 2000);
        }

        function timeSince(dateString) {
            const date = new Date(dateString);
            const seconds = Math.floor((new Date() - date) / 1000);

            if (seconds < 60) return seconds + 's';
            if (seconds < 3600) return Math.floor(seconds / 60) + 'm';
            return Math.floor(seconds / 3600) + 'h';
        }

        // Check update status on page load
        window.addEventListener('DOMContentLoaded', async () => {
            try {
                const response = await fetch('/api/status');
                const data = await response.json();

                if (data.update_running) {
                    document.getElementById('update-status').textContent =
                        '⏳ Update in progress (started ' + timeSince(data.last_started) + ' ago)';
                    pollForCompletion();
                }
            } catch (error) {
                // Running static file, API not available - hide update button
                document.getElementById('update-btn').style.display = 'none';
            }
        });
    </script>
</body>
</html>
"""

    return html


def main():
    """Main function to generate and save static HTML"""
    print("=" * 60)
    print("🪿 GOOSE - Static HTML Generator")
    print("=" * 60)

    try:
        html_content = generate_html()

        # Use OUTPUT_DIR from config
        output_dir = OUTPUT_DIR
        os.makedirs(output_dir, exist_ok=True)

        # Write to index.html
        output_path = os.path.join(output_dir, 'index.html')
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(html_content)

        # Copy variants.css to output directory
        variants_css_source = os.path.join(os.path.dirname(__file__), 'static', 'variants.css')
        variants_css_dest = os.path.join(output_dir, 'variants.css')
        if os.path.exists(variants_css_source):
            shutil.copy2(variants_css_source, variants_css_dest)
            print(f"  Copied variants.css to output directory")

        print(f"\n✓ Static HTML generated successfully!")
        print(f"  Output file: {output_path}")
        print(f"  File size: {len(html_content) / 1024:.1f} KB")

    except Exception as e:
        print(f"\n✗ Error generating static HTML: {e}")
        import traceback
        traceback.print_exc()
        return 1

    return 0


if __name__ == '__main__':
    exit(main())

