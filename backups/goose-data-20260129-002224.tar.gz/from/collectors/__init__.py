"""
GOOSE Data Collectors
"""
