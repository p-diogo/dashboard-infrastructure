"""
Notion Data Collector for GOOSE
Fetches proposals and votes from Notion API
"""

import time
from datetime import datetime
from typing import List, Dict, Optional
from config import NOTION_CONFIG, QUORUM_THRESHOLD
from database import save_proposal, save_vote, save_member, get_connection, update_last_sync, delete_notion_proposals_not_in_ids
from utils.retry import with_retry
from utils.fuzzy_matcher import match_notion_name_to_address
from utils.notion_client import NotionClient


@with_retry(max_retries=5, initial_delay=2.0, timeout=30)
def fetch_notion_database():
    """Fetch all pages from Notion database with retry logic"""
    client = NotionClient(
        token=NOTION_CONFIG['api_token'],
        database_id=NOTION_CONFIG['database_id']
    )
    return client.query_database()


@with_retry(max_retries=5, initial_delay=1.0, timeout=30)
def fetch_related_voters(page_id: str, relation_property: str):
    """Fetch voter information from related Yes/No Voters List databases"""
    client = NotionClient(
        token=NOTION_CONFIG['api_token'],
        database_id=NOTION_CONFIG['voters_database_id']
    )

    # Fetch the page to get relation IDs, then fetch related pages
    url = f"{NotionClient.BASE_URL}/pages/{page_id}"
    import requests
    response = requests.get(url, headers=client.headers)
    response.raise_for_status()
    page_data = response.json()

    # Extract relation IDs
    relations = page_data.get("properties", {}).get(relation_property, {}).get("relation", [])
    related_ids = [r["id"] for r in relations]

    # Fetch each related page
    related_pages = []
    for related_id in related_ids:
        url = f"{NotionClient.BASE_URL}/pages/{related_id}"
        response = requests.get(url, headers=client.headers)
        response.raise_for_status()
        related_pages.append(response.json())

        # Rate limiting
        time.sleep(0.3)

    return related_pages


def parse_notion_date(date_dict: Optional[Dict]) -> Optional[int]:
    """Convert Notion date object to Unix timestamp"""
    if not date_dict or not date_dict.get('start'):
        return None
    try:
        dt = datetime.fromisoformat(date_dict['start'].replace('Z', '+00:00'))
        return int(dt.timestamp())
    except:
        return None


def calculate_quorum_time_notion(votes: List[Dict]) -> Optional[int]:
    """Calculate when quorum was reached for a Notion proposal"""
    if len(votes) < QUORUM_THRESHOLD:
        return None

    # Sort votes by timestamp (from relation property)
    sorted_votes = sorted(votes, key=lambda x: x.get('voted_at', 0))

    if len(sorted_votes) >= QUORUM_THRESHOLD:
        return sorted_votes[QUORUM_THRESHOLD - 1]['voted_at']

    return None


def is_active_status(status: str) -> bool:
    """Check if proposal status is considered active (case-insensitive)"""
    active_statuses = NOTION_CONFIG.get('active_statuses', ['In Progress', 'Not Started'])
    # Case-insensitive comparison
    return status.lower() in [s.lower() for s in active_statuses] if status else False


def collect_notion_data():
    """Main function to collect all Notion data"""
    # Check if Notion is configured
    if not NOTION_CONFIG.get('api_token') or not NOTION_CONFIG.get('database_id'):
        print("⊘ Notion not configured - skipping data collection")
        return

    print("Fetching Notion proposals...")
    pages = fetch_notion_database()

    print(f"Found {len(pages)} pages in Notion database")

    active_count = 0
    skipped_count = 0
    seen_page_ids = set()  # Track all page IDs seen in this sync

    for page in pages:
        page_id = page['id']
        seen_page_ids.add(page_id)  # Track this page ID

        # Extract title (try multiple property names)
        title = 'Untitled'
        for prop_name in ['Proposal Name', 'Name', 'Title', 'proposal']:
            title_prop = page.get('properties', {}).get(prop_name, {})
            title_list = title_prop.get('title', [])
            if title_list and len(title_list) > 0:
                title = title_list[0].get('plain_text', 'Untitled')
                break

        # Extract status
        status_prop = page.get('properties', {}).get('Status', {})
        select_prop = status_prop.get('select') if status_prop else None
        if select_prop:
            status = select_prop.get('name', 'Unknown')
        else:
            status = 'Unknown'

        # Extract created time
        created_time = page.get('created_time')  # ISO string from Notion

        # Extract deadline
        deadline = parse_notion_date(page.get('properties', {}).get('Deadline', {}))

        # Filter by active status
        if not is_active_status(status):
            skipped_count += 1
            continue

        active_count += 1
        print(f"Processing active proposal {active_count}: {title[:50]}...")

        # Convert created_time to timestamp
        created_at = int(datetime.fromisoformat(created_time.replace('Z', '+00:00')).timestamp())

        # Fetch Yes/No voter lists (relation to another database)
        yes_voters_data = fetch_related_voters(page_id, 'Yes Voters List')
        no_voters_data = fetch_related_voters(page_id, 'No Voters List')

        # Combine all votes with timestamps
        all_votes = []

        for voter_page in yes_voters_data:
            # Extract voter name and timestamp from related page
            voter_name = voter_page.get('properties', {}).get('Name', {}).get('title', [{}])[0].get('plain_text', '')
            voted_at = parse_notion_date(voter_page.get('properties', {}).get('Voted At', {}))
            if voted_at:
                all_votes.append({
                    'name': voter_name,
                    'voted_at': voted_at,
                    'choice': 'yes'
                })

        for voter_page in no_voters_data:
            voter_name = voter_page.get('properties', {}).get('Name', {}).get('title', [{}])[0].get('plain_text', '')
            voted_at = parse_notion_date(voter_page.get('properties', {}).get('Voted At', {}))
            if voted_at:
                all_votes.append({
                    'name': voter_name,
                    'voted_at': voted_at,
                    'choice': 'no'
                })

        # Calculate quorum time
        quorum_time = calculate_quorum_time_notion(all_votes)

        # Save proposal (reuse proposals table with platform='notion')
        proposal_data = {
            'id': page_id,
            'title': title,
            'created_at': created_at,
            'start_time': created_at,  # Same as created for Notion
            'end_time': deadline,  # May be None
            'state': status,
            'quorum_reached_at': quorum_time,
            'platform': 'notion'
        }
        save_proposal(proposal_data)

        # Save votes with fuzzy matching to addresses
        for vote in all_votes:
            voter_name = vote['name']
            voted_at = vote['voted_at']

            # Fuzzy match Notion name to council member address
            address = match_notion_name_to_address(voter_name)

            if address:
                save_vote(
                    item_id=page_id,
                    voter_address=address,
                    voted_at=voted_at,
                    platform='notion'
                )
                save_member(address)
            else:
                print(f"  ⚠️ Could not match Notion name '{voter_name}' to council member address")

        # Rate limiting: Notion free tier is 3 requests/second
        # We already have delays in fetch_related_voters, but add a small extra delay
        time.sleep(0.2)

    # Clean up proposals that were deleted from Notion
    deleted_count = delete_notion_proposals_not_in_ids(seen_page_ids)
    if deleted_count > 0:
        print(f"  🗑️ Cleaned up {deleted_count} deleted proposal(s) from database")

    print(f"Notion data collection complete! Active: {active_count}, Skipped: {skipped_count}")

    # Update sync state
    update_last_sync('notion', int(time.time()), active_count)


if __name__ == "__main__":
    from database import init_db
    init_db()
    collect_notion_data()
