"""
Snapshot Data Collector for GOOSE
Fetches proposals and votes from Snapshot GraphQL API
"""

import requests
import time
from datetime import datetime
from config import SNAPSHOT_SPACE, SNAPSHOT_API_URL, QUORUM_THRESHOLD
from database import save_proposal, save_vote, save_member, get_connection
from utils.retry import with_retry


@with_retry(max_retries=10, initial_delay=5.0, timeout=30)
def fetch_proposals(limit=100):
    """Fetch proposals from Snapshot with retry logic"""
    query = """
    query Proposals($space: String!, $first: Int!) {
      proposals(
        first: $first,
        where: { space: $space },
        orderBy: "created",
        orderDirection: desc
      ) {
        id
        title
        body
        start
        end
        state
        created
        author
        votes
      }
    }
    """

    variables = {
        "space": SNAPSHOT_SPACE,
        "first": limit
    }

    response = requests.post(
        SNAPSHOT_API_URL,
        json={"query": query, "variables": variables}
    )
    response.raise_for_status()
    return response.json().get("data", {}).get("proposals", [])


@with_retry(max_retries=10, initial_delay=5.0, timeout=30)
def fetch_votes_for_proposal(proposal_id):
    """Fetch all votes for a specific proposal with retry logic"""
    query = """
    query Votes($proposal: String!) {
      votes(
        first: 1000,
        where: { proposal: $proposal }
      ) {
        id
        voter
        created
        choice
        vp
      }
    }
    """

    variables = {
        "proposal": proposal_id
    }

    response = requests.post(
        SNAPSHOT_API_URL,
        json={"query": query, "variables": variables}
    )
    response.raise_for_status()
    return response.json().get("data", {}).get("votes", [])


def calculate_quorum_time(votes):
    """Calculate when quorum was reached for a proposal (votes pre-fetched)"""
    if len(votes) < QUORUM_THRESHOLD:
        return None

    # Sort votes by timestamp
    sorted_votes = sorted(votes, key=lambda x: x['created'])

    # The time when the 6th vote was cast
    if len(sorted_votes) >= QUORUM_THRESHOLD:
        return sorted_votes[QUORUM_THRESHOLD - 1]['created']

    return None


def collect_snapshot_data():
    """Main function to collect all Snapshot data"""
    print("Fetching Snapshot proposals...")
    proposals = fetch_proposals()

    print(f"Found {len(proposals)} proposals")

    for i, proposal in enumerate(proposals):
        print(f"Processing proposal {i+1}/{len(proposals)}: {proposal['title'][:50]}...")

        # Fetch votes ONCE per proposal
        votes = fetch_votes_for_proposal(proposal['id'])

        # Calculate quorum time using fetched votes
        quorum_time = calculate_quorum_time(votes)

        # Save proposal
        proposal_data = {
            'id': proposal['id'],
            'title': proposal['title'],
            'created_at': proposal['created'],
            'start_time': proposal['start'],
            'end_time': proposal['end'],
            'state': proposal['state'],
            'quorum_reached_at': quorum_time
        }
        save_proposal(proposal_data)

        # Save author as member
        save_member(proposal['author'])

        # Save votes (already fetched above)
        for vote in votes:
            save_vote(
                item_id=proposal['id'],
                voter_address=vote['voter'],
                voted_at=vote['created'],
                platform='snapshot'
            )
            save_member(vote['voter'])

        # Delay to respect 60 req/min limit (1 second between proposals)
        # Plus small buffer for request processing time
        time.sleep(1.2)

    print("Snapshot data collection complete!")


if __name__ == "__main__":
    from database import init_db
    init_db()
    collect_snapshot_data()
