#!/usr/bin/env python3
"""
THE GRUMPY GOOSE Setup Script
Initializes the database and collects initial data
"""

import sys
from database import init_db
from collectors.snapshot import collect_snapshot_data
from collectors.safe import collect_safe_data
from collectors.notion import collect_notion_data
from config import SAFES, NOTION_CONFIG


def main():
    print("=" * 60)
    print("🪿 THE GRUMPY GOOSE Setup")
    print("Governance Oversight & Operational Speed Evaluator")
    print("=" * 60)
    print()

    # Step 1: Initialize database
    print("[1/5] Initializing database...")
    try:
        init_db()
        print("✓ Database initialized successfully\n")
    except Exception as e:
        print(f"✗ Database initialization failed: {e}")
        sys.exit(1)

    # Step 2: Collect Snapshot data
    print("[2/5] Collecting Snapshot data...")
    print("This may take a few minutes depending on the number of proposals...")
    try:
        collect_snapshot_data()
        print("✓ Snapshot data collected successfully\n")
    except Exception as e:
        print(f"✗ Snapshot data collection failed: {e}")
        print("You can try running: python collectors/snapshot.py")
        print()

    # Step 3: Collect Safe data from all Safes
    print("[3/5] Collecting Safe multisig data...")
    safes_collected = 0
    safes_failed = 0
    for safe in SAFES:
        label = safe.get('label', safe['chain'])
        chain = safe.get('chain', 'unknown')
        print(f"  Collecting from {label} ({chain})...")
        try:
            collect_safe_data(safe)
            safes_collected += 1
        except Exception as e:
            print(f"  ✗ Failed to collect from {label}: {e}")
            safes_failed += 1
            continue  # Continue with other Safes even if one fails

    if safes_collected > 0:
        print(f"✓ Safe data collected successfully ({safes_collected}/{len(SAFES)} Safes)\n")
    if safes_failed > 0:
        print(f"⚠ Warning: Failed to collect from {safes_failed} Safe(s)\n")

    # Step 4: Collect Notion data
    print("[4/5] Collecting Notion data...")
    if NOTION_CONFIG.get('api_token') and NOTION_CONFIG.get('database_id'):
        try:
            collect_notion_data()
            print("✓ Notion data collected successfully\n")
        except Exception as e:
            print(f"✗ Notion data collection failed: {e}")
            print("You can try running: python collectors/notion.py")
            print()
    else:
        print("⊘ Notion not configured - skipping\n")

    # Step 5: Update member names from CSV
    print("[5/5] Updating council member names...")
    try:
        from database import update_member_names
        count = update_member_names()
        print(f"✓ Updated {count} member names from CSV\n")
    except Exception as e:
        print(f"✗ Member name update failed: {e}")
        print()

    # Done
    print("=" * 60)
    print("✓ Setup complete!")
    print()
    print("To generate the static dashboard, run:")
    print("  python generate_static.py")
    print()
    print("Then open index.html in your browser")
    print("=" * 60)


if __name__ == "__main__":
    main()
