"""
Database setup and management for GOOSE
"""

import sqlite3
from datetime import datetime
import config


def init_db():
    """Initialize the database with required tables and run migrations"""
    conn = sqlite3.connect(config.DATABASE_PATH)
    cursor = conn.cursor()

    # Proposals table (Snapshot)
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS proposals (
            id TEXT PRIMARY KEY,
            title TEXT,
            created_at INTEGER,
            start_time INTEGER,
            end_time INTEGER,
            state TEXT,
            quorum_reached_at INTEGER,
            platform TEXT DEFAULT 'snapshot'
        )
    """)

    # Transactions table (Safe)
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS transactions (
            id TEXT PRIMARY KEY,
            safe_tx_hash TEXT UNIQUE,
            created_at INTEGER,
            executed_at INTEGER,
            quorum_reached_at INTEGER,
            nonce INTEGER,
            safe_address TEXT,
            platform TEXT DEFAULT 'safe'
        )
    """)

    # Votes table (for both Snapshot votes and Safe signatures)
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS votes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            item_id TEXT,
            voter_address TEXT,
            voted_at INTEGER,
            platform TEXT,
            UNIQUE(item_id, voter_address, platform)
        )
    """)

    # Members table (to track council members)
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS members (
            address TEXT PRIMARY KEY,
            ens_name TEXT
        )
    """)

    # Sync state table (to track last successful fetch times)
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS sync_state (
            platform TEXT PRIMARY KEY,
            last_sync INTEGER,
            last_item_count INTEGER
        )
    """)

    # Initialize sync state for platforms if not exists
    cursor.execute("""
        INSERT OR IGNORE INTO sync_state (platform, last_sync, last_item_count)
        VALUES ('snapshot', 0, 0)
    """)
    cursor.execute("""
        INSERT OR IGNORE INTO sync_state (platform, last_sync, last_item_count)
        VALUES ('safe', 0, 0)
    """)
    cursor.execute("""
        INSERT OR IGNORE INTO sync_state (platform, last_sync, last_item_count)
        VALUES ('notion', 0, 0)
    """)

    conn.commit()
    conn.close()

    # Run migrations after tables are created and committed
    try:
        from migrations import run_migrations
        run_migrations()
    except ImportError:
        # Migrations module not yet created
        pass

    print("Database initialized successfully")


def get_connection():
    """Get a database connection"""
    return sqlite3.connect(config.DATABASE_PATH)


def save_proposal(proposal_data):
    """Save a Snapshot or Notion proposal to the database"""
    conn = get_connection()
    cursor = conn.cursor()

    # Get platform from proposal_data, default to 'snapshot'
    platform = proposal_data.get('platform', 'snapshot')

    cursor.execute("""
        INSERT OR REPLACE INTO proposals
        (id, title, created_at, start_time, end_time, state, quorum_reached_at, platform)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        proposal_data['id'],
        proposal_data['title'],
        proposal_data['created_at'],
        proposal_data['start_time'],
        proposal_data['end_time'],
        proposal_data['state'],
        proposal_data.get('quorum_reached_at'),
        platform
    ))

    conn.commit()
    conn.close()


def save_transaction(tx_data):
    """Save a Safe transaction to the database"""
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("""
        INSERT OR REPLACE INTO transactions
        (id, safe_tx_hash, created_at, executed_at, quorum_reached_at, nonce, safe_address)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    """, (
        tx_data['id'],
        tx_data['safe_tx_hash'],
        tx_data['created_at'],
        tx_data.get('executed_at'),
        tx_data.get('quorum_reached_at'),
        tx_data['nonce'],
        tx_data.get('safe_address')  # May be None for backward compatibility
    ))

    conn.commit()
    conn.close()


def save_vote(item_id, voter_address, voted_at, platform):
    """Save a vote or signature"""
    conn = get_connection()
    cursor = conn.cursor()

    try:
        cursor.execute("""
            INSERT OR IGNORE INTO votes
            (item_id, voter_address, voted_at, platform)
            VALUES (?, ?, ?, ?)
        """, (item_id, voter_address, voted_at, platform))

        conn.commit()
    except sqlite3.IntegrityError:
        pass  # Vote already exists
    finally:
        conn.close()


def save_member(address, ens_name=None):
    """Save or update a council member"""
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("""
        INSERT OR REPLACE INTO members (address, ens_name)
        VALUES (?, ?)
    """, (address, ens_name))

    conn.commit()
    conn.close()


def update_member_names():
    """Update database with council member names from CSV"""
    import council_lookup
    return council_lookup.update_member_names_in_db()


def get_member_display_name(address):
    """Get formatted display name for a member address"""
    import council_lookup
    return council_lookup.format_member_name(address)


def get_last_sync(platform):
    """Get the last sync timestamp for a platform"""
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("""
        SELECT last_sync, last_item_count FROM sync_state WHERE platform = ?
    """, (platform,))

    result = cursor.fetchone()
    conn.close()

    if result:
        return result[0], result[1]
    return 0, 0


def update_last_sync(platform, last_sync, item_count):
    """Update the last sync timestamp for a platform"""
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("""
        UPDATE sync_state SET last_sync = ?, last_item_count = ?
        WHERE platform = ?
    """, (last_sync, item_count, platform))

    conn.commit()
    conn.close()


def get_max_created_timestamp(platform):
    """Get the most recent created_at timestamp for a platform"""
    conn = get_connection()
    cursor = conn.cursor()

    if platform == 'snapshot':
        cursor.execute("SELECT MAX(created_at) FROM proposals")
    elif platform == 'safe':
        cursor.execute("SELECT MAX(created_at) FROM transactions")
    else:
        conn.close()
        return 0

    result = cursor.fetchone()
    conn.close()

    return result[0] if result and result[0] else 0


def delete_notion_proposals_not_in_ids(existing_ids):
    """
    Delete Notion proposals that are no longer in Notion.

    Args:
        existing_ids: Set of page IDs that currently exist in Notion

    Returns:
        Number of proposals deleted
    """
    conn = get_connection()
    cursor = conn.cursor()

    # Get all Notion proposal IDs
    cursor.execute("SELECT id FROM proposals WHERE platform = 'notion'")
    all_ids = [row[0] for row in cursor.fetchall()]

    # Find IDs to delete (those in DB but not in Notion)
    ids_to_delete = set(all_ids) - set(existing_ids)

    if ids_to_delete:
        # Delete votes first (foreign key relationship)
        placeholders = ','.join('?' * len(ids_to_delete))
        cursor.execute(
            f"DELETE FROM votes WHERE item_id IN ({placeholders}) AND platform = 'notion'",
            list(ids_to_delete)
        )

        # Then delete proposals
        cursor.execute(
            f"DELETE FROM proposals WHERE id IN ({placeholders}) AND platform = 'notion'",
            list(ids_to_delete)
        )

        conn.commit()
        count = len(ids_to_delete)
    else:
        count = 0

    conn.close()
    return count


if __name__ == "__main__":
    init_db()
